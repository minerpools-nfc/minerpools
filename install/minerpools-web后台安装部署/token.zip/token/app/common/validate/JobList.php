<?php
/**
 *
 * @创建时间 2021/3/24 11:06
 */

namespace app\common\validate;


class JobList extends BaseValidate
{
    protected $rule = [
        'job_enable' => 'in:0,1',
        'execresult' => 'in:0,1',
    ];
}