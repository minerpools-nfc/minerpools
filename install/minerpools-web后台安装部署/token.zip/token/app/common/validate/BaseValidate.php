<?php
/**
 *
 * @创建时间 2021/3/23 13:45
 */

namespace app\common\validate;


use think\facade\Request;
use think\Validate;


class BaseValidate extends Validate
{
    public function goCheck()
    {
        $request = Request::instance();
        $param = $request->param();

        $result = $this->batch()->check($param);
        if (!$result)
        {
            //校验不通过
            $errMsg = implode($this->error, '; ');
            return result([], 0, $errMsg);
        }
        else
        {
            return true;
        }
    }

    protected function isPositiveInteger($value, $rule = '', $data = '', $field = ''){

        if (ctype_digit($value) && ($value + 0) > 0){
            return true;
        }else{
            return false;
        }
    }



}