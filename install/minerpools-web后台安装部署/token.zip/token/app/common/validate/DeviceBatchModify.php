<?php
/**
 *
 * @创建时间 2021/3/30 16:39
 */

namespace app\common\validate;


class DeviceBatchModify extends BaseValidate
{
    protected $rule = [
        'ids' => 'require',
        'releasedays' => 'number',
        'lockdays' => 'number'
       // 'releasedays' => 'isPositiveInteger',
       // 'lockdays' => 'isPositiveInteger'
    ];

    protected $message = [
        'releasedays' => 'releasedays必需是整数',
        'lockdays' => 'lockdays必需是整数',
    ];

}