<?php
/**
 *
 * @创建时间 2021/3/23 13:50
 */

namespace app\common\validate;


use think\Request;

class SettingModify extends BaseValidate
{
    protected $rule = [
        'setting' => 'require|checkSettings'
    ];

    protected $singleRule = [
        'cfgid' => 'require|isPositiveInteger',
        'prop_value' => 'require|isPositiveInteger'
    ];

    protected function checkSettings($values){
        if (!is_array($values)){
            return result([], 0, '参数格式不正确');
        }

        if (empty($values)){
            return result([], 0, '参数不能为空');
        }

        foreach ($values as $value){
            $this->checkSetting($value);
        }
        return true;
    }

    protected function checkSetting($value){
        $validate = new BaseValidate();
        $validate->rule($this->singleRule);
        $result = $validate->check($value);
        if (!$result){
            return result([], 0, '请填写数字,且不能小于0!');
        }
    }
}