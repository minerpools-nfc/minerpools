<?php
/**
 *
 * @创建时间 2021/3/26 14:06
 */

namespace app\common\validate;


class TokenRecord extends BaseValidate
{
    protected $rule = [
        'start_time' => 'date',
        'end_time' => 'date'
    ];





}