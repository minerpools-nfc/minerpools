<?php
/**
 *
 * @创建时间 2021/3/29 9:56
 */

namespace app\common\validate;


class UserStatus extends BaseValidate
{
    protected $rule = [
        'status' => 'require|in:0,1,2,3,4',
        'uid' => 'require|length:15',
        'address' => 'require|min:20'
    ];

    protected $scene = [
        'status' => ['status', 'uid'],
        'address' => ['uid', 'address']
    ];
}