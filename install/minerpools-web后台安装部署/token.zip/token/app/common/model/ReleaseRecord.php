<?php
/**
 *
 * @创建时间 2021/3/25 9:44
 */

namespace app\common\model;


class ReleaseRecord extends BaseModel
{


    //7. 用户已提取 zs_release_record draw_status = 3 sharenum
    //8. 释放未提取 zs_release_record draw_status ！= 3 nfc_num
    public static function static()
    {
        $result = self::field('SUM(IF(draw_status = 3, sharenum, 0)) AS user_has_take')
            ->field('SUM(takenum) AS `release`')
            ->field('SUM(IF(draw_status <> 3, sharenum, 0)) AS user_un_take')
            ->field('SUM(IF(draw_status <> 3, nfc_num, 0)) AS un_take')
            ->select()
            ->toArray();
        return $result[0];
    }

}