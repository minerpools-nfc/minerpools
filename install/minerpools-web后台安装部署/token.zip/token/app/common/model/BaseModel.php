<?php
namespace app\common\model;
use think\Model;

class BaseModel extends Model
{
 
    protected $autoWriteTimestamp = true;

  
    public static function addSave($data)   //新增
    {
        if (!empty($data)) {
            foreach ($data as $k => $v) {
                if (is_array($v)) $data[$k] = implode(',', $v);  //checkbox 分隔字符串写入
            }
        }
    
            $result = self::create($data); 
            if($result) {
                return ['code' => 1, 'msg' => '新增成功'];
            } else {
                return ['code' => 0, 'msg' => '新增失败'];
            }
      
       
    }



     public static function editSave($data)   //编辑
    {
        if (!empty($data)) {
            foreach ($data as $k => $v) {
                if (is_array($v)) $data[$k] = implode(',', $v);  //checkbox 分隔字符串写入
            }
        }
        $result = self::update($data);
        if ($result) {
                return ['code' => 1, 'msg' => '修改成功'];
        } else {
                return ['code' => 0, 'msg' => '修改失败'];
        }
       
    }


    
    public static function del($ids){ // 删除数据 一个或多个
       
        $ids = explode(',',$ids);
        self::destroy($ids);
        return ['code'=>1,'msg'=>'删除成功!'];
    }


    public static function switchChange($id,$field,$value){
       
         $row = self::find($id);
         $row->$field= $value;
         $row -> save();
         $data=['code'=>1, 'msg'=>'操作成功!'];
         return json($data);
    }

    public static function inputChange($id,$field,$value){
       
         $row = self::find($id);
         $row->$field= $value;
         $row -> save();
         $data=['code'=>1, 'msg'=>'操作成功!'];
         return json($data);
    }
    

    



}