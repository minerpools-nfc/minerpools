<?php
/**
 *
 * @创建时间 2021/3/29 13:50
 */

namespace app\common\model;


class JobLog extends BaseModel
{
    public function getSpeedsAttr($value){
        if ($value){
            return $value / 1000;
        }
        return $value;
    }

    public static function pageList($pageNum, $pageSize, $where=[], $field='*')
    {
        return self::where($where)->field($field)->order('exectime','desc')->page($pageNum,$pageSize)->select();
    }
}