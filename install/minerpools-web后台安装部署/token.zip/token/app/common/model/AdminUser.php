<?php
namespace app\common\model;

use think\facade\Request;
use think\facade\Db;


class AdminUser extends BaseModel
{
   
     public function authGroup()
    {
        return $this->belongsTo("authGroup","auth_group_id");
    }
       


    public static function pageList($pageNum,$pageSize,$field='*',$where=[],$order=['id'=>'desc'])
    {

        $tablelist = self::where($where)->field($field)->order($order)->page($pageNum,$pageSize)->select();  

         foreach ($tablelist as $k => $v) {
			// if ($tablelist[$k]["login_time"]) {
			// 	    $v["login_time"] = date('Y-m-d G:i:s',$v["login_time"]);
			// }
            if ($tablelist[$k]["auth_group_id"]) {
                    $v["auth_group_id"] = $v->authGroup['title'];
            }
		    } 
          $tablelist->hidden(['authGroup']);    

         $total= self::where($where)->count();

         $lists=[
          'total'=>$total,
          'tablelist'=>$tablelist
         ];
         return $lists;
    }


      public static function getOne($where=[],$field='*')
    {

        $item = self::where($where)->field($field)->find();  
        if($item["auth_group_id"]) {
                 $item["group_name"] = $item->authGroup['title'];
        }

        $item->hidden(['authGroup']);

        return $item;
    }


}