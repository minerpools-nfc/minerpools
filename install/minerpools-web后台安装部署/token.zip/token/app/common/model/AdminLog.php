<?php
namespace app\common\model;

use think\facade\Request;
use think\facade\Db;


class AdminLog extends BaseModel
{
   
    
    public function adminUser()
	{
		return $this->belongsTo("adminUser","operate_id");
	}
   


    public static function tableList($where,$start,$pageSize,$order)
    {

        $tablelist = self::where($where)->order($order)->limit($start,$pageSize)->select();  

     
       
  //       foreach ($tablelist as $k => $v) {
		// 	if ($tablelist[$k]["operate_id"]) {
		// 		    $v["operate_id"] = $v->adminUser["username"];
		// 	}
		// }
              

        return $tablelist;
    }


}