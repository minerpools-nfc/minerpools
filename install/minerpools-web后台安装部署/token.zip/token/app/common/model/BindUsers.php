<?php
namespace app\common\model;

use think\facade\Request;
use think\facade\Db;


class BindUsers extends BaseModel
{


   protected $pk = 'userid';
   
 
    public static function pageList($pageNum,$pageSize,$field='*',$where=[],$order=['id'=>'desc'])
    {

        $tablelist = self::where($where)->field($field)->order($order)->page($pageNum,$pageSize)->select();  

        $total= self::where($where)->count();


       //  foreach ($tablelist as $k => $v) {

       //      if ($tablelist[$k]["typeid"]) {
       //              $v["typeid"] = $v->DevicesType['type_name'];
       //      }
       //   } 

   //    $tablelist->hidden(['DevicesType']);    

       $list=[
          'total'=>$total,
          'tablelist'=>$tablelist
       ];


        return $list;
    }



     public static function getOne($where=[],$field='*')
    {

       //  $item = self::where($where)->field($field)->find();  

       // if ($item["policyid"]) {
       //           $item["policyname"] = $item->DeviceDrawPolicy['policy_name'];
       // }

       // if($item){
       //   $item->hidden(['DeviceDrawPolicy','owerid','ower_name','refereruserid']);    
       // } 
  
       //  return $item;
    }

    public static function countPointAlarm(){
        return self::where('mbpoint_alarm', 1)->count();
    }


}