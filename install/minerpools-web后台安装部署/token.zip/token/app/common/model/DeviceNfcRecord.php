<?php
namespace app\common\model;

use think\facade\Request;
use think\facade\Db;


class DeviceNfcRecord extends BaseModel
{

      public static function pageList($pageNum,$pageSize,$field='*',$where=[],$order=['id'=>'desc'])
    {
        $tablelist = self::where($where)->field($field)->order($order)->page($pageNum,$pageSize)->select();
        return $tablelist;
    }




}