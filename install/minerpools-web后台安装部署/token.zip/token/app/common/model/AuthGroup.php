<?php
namespace app\common\model;

use think\facade\Request;
use think\facade\Db;


class AuthGroup extends BaseModel
{
   
     public static function pageList($pageNum,$pageSize,$field='*',$where=[],$order=['id'=>'desc'])
    {

        $tablelist = self::where($where)->field($field)->order($order)->page($pageNum,$pageSize)->select();  

         $total= self::where($where)->count();

         $lists=[
          'total'=>$total,
          'tablelist'=>$tablelist
         ];
         return $lists;
    }



     public static function getOne($where=[],$field='*')
    {

        $item = self::where($where)->field($field)->find();  
        return $item;
    }
}