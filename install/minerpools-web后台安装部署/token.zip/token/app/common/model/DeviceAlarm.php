<?php
namespace app\common\model;

use think\facade\Request;
use think\facade\Db;


class DeviceAlarm extends BaseModel
{



    public function BindUsers()
    {
        return $this->belongsTo("BindUsers", "userid", 'userid');
    }



    public static function pageList($pageNum,$pageSize,$field='*',$where=[],$order=['id'=>'desc'])
    {

        $tablelist = self::where($where)->field($field)->order($order)->page($pageNum,$pageSize)->select();  


        foreach ($tablelist as $k => $v)
        {

             if ($tablelist[$k]["userid"]){              
                $v['devicesn']=$tablelist[$k]['devicesn'].'/'.$v->BindUsers['firstname'];
             }
          
        }
         $tablelist->hidden(['BindUsers']);


        $total= self::where($where)->count();

         $lists=[
          'total'=>$total,
          'tablelist'=>$tablelist
         ];


        return $lists;

    
    }


}