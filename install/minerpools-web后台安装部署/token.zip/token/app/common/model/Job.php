<?php
/**
 *
 * @创建时间 2021/3/24 9:34
 */

namespace app\common\model;


class Job extends BaseModel
{
    public static function pageList($pageNum, $pageSize, $where=[], $field='*', $order=['jobid'=>'desc'])
    {
        return self::where($where)->field($field)->order($order)->page($pageNum,$pageSize)->select();
    }

    public static function count($where=[]){
        return self::where($where)->count();
    }
}