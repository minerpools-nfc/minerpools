<?php
namespace app\common\model;

use think\facade\Request;
use think\facade\Db;


class DrawApply extends BaseModel
{
   
     protected $pk = 'applyid';
   
    public function user(){
        return $this->belongsTo('BindUsers', 'userid', 'userid');
    }

    
    public static function pageList($pageNum,$pageSize,$field='*',$where=[],$order=['id'=>'desc'])
    {

        $tablelist = self::where($where)->field($field)->order($order)->page($pageNum,$pageSize)->select();  


         // foreach ($tablelist as $k => $v) {

         // } 

         $tablelist->hidden(['DeviceDrawPolicy']);    

        return $tablelist;
    }

    public static function countApplyNum(){
        return self::where('trans_status', 1)->count();
    }

    public static function getExportList($where){
        return self::where($where)->select();
    }

}