<?php
namespace app\common\model;

use think\facade\Request;
use think\facade\Db;


class DeviceDrawDetail extends BaseModel
{
   
     protected $pk = 'detailid';


     public function Devices()
    {
        return $this->belongsTo("Devices","devicesn");
    }
    
    public static function pageList($pageNum,$pageSize,$field='*',$where=[],$order=['id'=>'desc'])
    {

        $tablelist = self::where($where)->field($field)->order($order)->page($pageNum,$pageSize)->select();  

        $total= self::where($where)->count();

         foreach ($tablelist as $k => $v) {

                if($v["draw_transFlag"] == 1)  $v["draw_status_label"] = "待转账";
                if($v["draw_transFlag"] == 2)  $v["draw_status_label"] = "转账交易中";
                if($v["draw_transFlag"] == 3)  $v["draw_status_label"] = "转账成功";
                if($v["draw_transFlag"] == 4)  $v["draw_status_label"] = "转账失败";
                if($v["draw_transFlag"] == 5)  $v["draw_status_label"] = "划转中";
                if($v["draw_transFlag"] == 6)  $v["draw_status_label"] = "待执行";
         
         } 
         $lists=[
          'total'=>$total,
          'tablelist'=>$tablelist
         ];


         return $lists;
    }

}