<?php

namespace app\common\model;


class DeviceTockenRecord extends BaseModel
{

    public function device(){
        return $this->belongsTo('Devices', 'devicesn', 'devicesn');
    }

    public function releases(){
        return $this->hasMany('ReleaseRecord', 'flowid', 'flowid');
    }

    public static function pageList($pageNum, $pageSize, $field = '*', $where = [], $order = ['id' => 'desc'])
    {
        $tablelist = self::where($where)
            ->field($field)
            ->order($order)
            ->page($pageNum, $pageSize)
            ->select();

        foreach ($tablelist as $k => $v)
        {
            $v['user'] = $v->device->BindUsers ? $v->device->BindUsers->firstname : '';
            $v["flow_bill"] = flowbill_format($v["flow_bill"]); //GB
            $v["nfc_num"] = floatval($v["nfc_num"]);
            $v["sharenum"] = floatval($v["sharenum"]);
            $v["takenum"] = floatval($v["takenum"]);
             $v["user_release"] = floatval($v["user_release"]);
              $v["user_locknum"] = floatval($v["user_locknum"]);

            
        }
        return $tablelist->hidden(['device']);
    }


    public static function staticLockRecord()
    {
        $result = self::field('SUM(IFNULL(nfc_num,0) - IFNULL(hasrelease,0)) AS lock_total')
                ->field('SUM(takenum) AS take_total')
                ->field('SUM(sharenum) AS share_total')
                ->field('SUM(hasrelease) AS hasrelease_all')
                ->select()
                ->toArray();
        return $result[0];
    }
    


    public static function incomeCurve($where)
    {
        return self::field(
            'STR_TO_DATE(instime, "%Y-%m-%d") AS date, SUM(IFNULL(takenum,0)) AS takenum, SUM(IFNULL(sharenum,0)) AS sharenum, SUM(IFNULL(nfc_num,0)) AS nfc_num')
            ->where($where)
            ->group('date')
            //->fetchSql()
            ->select();
    }

}