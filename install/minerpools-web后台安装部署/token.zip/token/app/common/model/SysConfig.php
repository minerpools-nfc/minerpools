<?php
/**
 *
 * @创建时间 2021/3/23 10:10
 */

namespace app\common\model;


class SysConfig extends BaseModel
{

}