<?php
namespace app\common\model;

use think\facade\Request;
use think\facade\Db;


class DeviceDrawDay extends BaseModel
{
   
     protected $pk = 'dayid';
   
     public function DeviceDrawPolicy()
    {
        return $this->belongsTo("DeviceDrawPolicy","policyid",'policyid');
    }
       

    
    public static function pageList($pageNum,$pageSize,$field='*',$where=[],$order=['id'=>'desc'])
    {

        $tablelist = self::where($where)->field($field)->order($order)->page($pageNum,$pageSize)->select();  


         foreach ($tablelist as $k => $v) {

            if ($tablelist[$k]["policyid"]) {
                    $v["policyid_name"] = $v->DeviceDrawPolicy['policy_name'];
                    
            }
             if($v["draw_status"] == 0)  $v["draw_status_label"] = "待发放";
             if($v["draw_status"] == 1)  $v["draw_status_label"] = "已发放";
             if($v["draw_status"] == 2)  $v["draw_status_label"] = "发放失败";


         } 

         $tablelist->hidden(['DeviceDrawPolicy']);    

        return $tablelist;
    }

}