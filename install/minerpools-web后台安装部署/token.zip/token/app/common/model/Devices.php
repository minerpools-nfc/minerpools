<?php

namespace app\common\model;

use think\facade\Request;
use think\facade\Db;


class Devices extends BaseModel
{


    protected $pk = 'devicesn';

    public function DevicesType()
    {
        return $this->belongsTo("DevicesType", "typeid");
    }


    public function BindUsers()
    {
        return $this->belongsTo("BindUsers", "owerid", 'userid');
    }


    public static function pageList(
        $pageNum, $pageSize, $field = '*', $where = [], $order = ['id' => 'desc'],
        $haswhere = [])
    {

        $tablelist = self::hasWhere(
            'BindUsers', function ($query) {
            global $haswhere;
            $query->where($haswhere);
        })
            ->where($where)
            ->field($field)
            ->order($order)
            ->page($pageNum, $pageSize)
            ->select();

        $total = self::where($where)
            ->count();


        foreach ($tablelist as $k => $v)
        {

            if ($tablelist[$k]["typeid"])
            {
                $v["typeid"] = $v->DevicesType['name'];
            }
            if ($tablelist[$k]["owerid"])
            {
                $v["mbpoit"] = mbpoint_format($v->BindUsers['mbpoit']);
            }
        }

        $tablelist->hidden(['DevicesType', 'BindUsers']);

        $list = [
            'total' => $total,
            'tablelist' => $tablelist
        ];


        return $list;
    }


    public static function getOne($where = [], $field = '*')
    {

        $item = self::where($where)
            ->field($field)
            ->find();

        if ($item["typeid"])
        {
            $item["typename"] = $item->DevicesType['name'];
        }
        if ($item["owerid"])
        {
            $item["mbpoit"] = $item->BindUsers['mbpoint'];
        }

        if ($item["share_rate"]) {
            $item["share_rate"] =  floatval($item['share_rate']);
        }

        if ($item)
        {
            $item->hidden(['DevicesType', 'refereruserid', 'BindUsers']);
        }


        return $item;
    }

    /*
     * 设备相关统计，总数和在线离线数量
     */
    public static function static()
    {
        $result = self::field('COUNT(devicesn) as total')
            ->field('SUM(IF(online_status = 1, 1, 0)) as online')
            ->field('SUM(IF(online_status = 0, 1, 0)) as offline')
            ->where('delete_flag',1)
            ->select()
            ->toArray();
        return $result[0];
    }


    public static function getExportList($where){
        return self::where($where)->select();
    }


}