<?php
namespace app\common\middleware;

use think\facade\Request;
use think\Response;
use think\exception\HttpResponseException;
use think\facade\config;
use think\facade\Route;

class Abc
{
    public function handle($request, \Closure $next)
    {
        
       return $next($request);
    }

 
    

}
