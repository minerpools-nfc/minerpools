<?php
use think\exception\HttpResponseException;
use think\facade\Db;
use think\Response;
/**
 * 邮件
 *  $to    接收人 $subject 邮件标题 $content 邮件内容
 */
function send_email($to, $subject = '', $content = '')
{
    $mail = new PHPMailer\PHPMailer\PHPMailer();
    $mail->CharSet = 'UTF-8'; //设定邮件编码，默认ISO-8859-1，发中文须设置，否则乱码
    $mail->isSMTP();
    $mail->SMTPDebug = 0;
    //调试输出格式
    //$mail->Debugoutput = 'html';
    //smtp服务器
    $mail->Host = sysconfig('smtp_server');
    //端口 - likely to be 25, 465 or 587
    $mail->Port = sysconfig('smtp_port');

    if ($mail->Port == '465') {
        $mail->SMTPSecure = 'ssl';
    }// 使用安全协议
    //Whether to use SMTP authentication
    $mail->SMTPAuth = true;
    //发送邮箱
    $mail->Username = sysconfig('smtp_user');
    //密码
    $mail->Password = sysconfig('smtp_pwd');
    //Set who the message is to be sent from
    $mail->setFrom(sysconfig('smtp_user'), sysconfig('email_id'));
    //回复地址
    //$mail->addReplyTo('replyto@example.com', 'First Last');
    //接收邮件方
    if (is_array($to)) {
        foreach ($to as $v) {
            $mail->addAddress($v);
        }
    } else {
        $mail->addAddress($to);
    }

    $mail->isHTML(true);// send as HTML
    //标题
    $mail->Subject = $subject;
    //HTML内容转换
    $mail->msgHTML($content);
    return $mail->send();
}


function is_email($email)
{
    $chars = "/^([a-z0-9+_]|\\-|\\.)+@(([a-z0-9_]|\\-)+\\.)+[a-z]{2,6}\$/i";
    if (strpos($email, '@') !== false && strpos($email, '.') !== false) {
        if (preg_match($chars, $email)) {
            return true;
        } else {
            return false;
        }
    } else {
        return false;
    }
}


function is_mobile_phone($mobile_phone)
{
    $chars = "/^13[0-9]{1}[0-9]{8}$|15[0-9]{1}[0-9]{8}$|18[0-9]{1}[0-9]{8}$|17[0-9]{1}[0-9]{8}$|16[0-9]{1}[0-9]{8}$|19[0-9]{1}[0-9]{8}$/";
    if (preg_match($chars, $mobile_phone)) {
        return true;
    }
    return false;
}



function object2array($object)
{
    $array = array();
    if (is_object($object)) {
        foreach ($object as $key => $value) {
            $array[$key] = $value;
        }
    } else {
        $array = $object;
    }
    return $array;
}



function treeList($datas,$pidname='pid',$pid = 0,$level = 0) {
          $result=array();
          foreach ($datas as $key => $data){           
             if($data[$pidname]==$pid){
                $data['level'] = $level;
                $result[]=$data;
                $result=array_merge($result,treeList($datas,$pidname,$data['id'],$level+1));
            } 
        }
     return $result;
}

function childList($data,$pidname='pid',$pid = 0) {
         $List=array();
          foreach ($data as $key => $v){  
            if($v[$pidname]==$pid){ 
               $v['child']=childList($data,$pidname,$v['id']);
                $List[]=$v;           
            } 
        }
        return $List;
}


function api_result($data, int $code = 1, $msg = 'ok', string $type = '', array $header = []): Response
{
    $result = [
        'code' => $code,
        'msg' => $msg,
        'data' => $data
    ];
    $type = $type ?: 'json';
    $response = Response::create($result, $type)
        ->header($header);

    throw new HttpResponseException($response);
}




function curl_request($url, $data='',$method='GET',$header=[],$ssl=false){
 
             $curl = curl_init();       
         //     $user_agent = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/57.0.2987.110 Safari/537.36';
          // curl_setopt($curl, CURLOPT_USERAGENT, $user_agent);  

             curl_setopt($curl, CURLOPT_TIMEOUT, 30);

             if($ssl){
             // curl_setopt($curl, CURLOPT_CAINFO, '/cert/ca.crt');  # CA 证书地址
            //  curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, true);    # 禁用后cURL将终止从服务端进行验证
             // curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 2);        
               # 设置为 1 是检查服务器SSL证书中是否存在一个公用名；设置成 2，会检查公用名是否存在，并且是否与提供的主机名匹配；0 为不检查名称。 在生产环境中，这个值应该是 2（默认值）。
                 # 公用名(Common Name)一般来讲就是填写你将要申请SSL证书的域名 (domain)或子域名(sub domain)
             }else{
                   curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);    # 禁用后cURL将终止从服务端进行验证，默认为 true
                   curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
             }
    

            if ($method == 'POST'){

                $data = is_array($data) ? http_build_query($data) : $data;                 
                curl_setopt($curl, CURLOPT_URL, $url);
                curl_setopt($curl, CURLOPT_POST,1);
                curl_setopt($curl, CURLOPT_POSTFIELDS, $data);

            }elseif($method == 'POST_JSON'){

              curl_setopt($curl, CURLOPT_URL, $url);
              curl_setopt($curl, CURLOPT_POST,1);
              curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
              curl_setopt($curl, CURLOPT_HTTPHEADER, [
                    'Content-Type: application/json; charset=utf-8',
                    'Content-Length: '.strlen($data)
                ]); 

            }else{
              
                $data = is_array($data) ? http_build_query($data) : $data;                
                $url = $data ?   $url . '?' . $data : $url;
                curl_setopt($curl,CURLOPT_URL, $url);                
            }

 
            if(!empty($header)){
                curl_setopt($curl, CURLOPT_HTTPHEADER, $header);
                curl_setopt($curl, CURLOPT_HEADER, 0);//返回response头部信息是否处理响应头，启用时会将头文件的信息作为数据流输出
            }

         
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, TRUE);   //# TRUE 将curl_exec()获取的信息以字符串返回，而不是直接输出。
            $output = curl_exec($curl);
            curl_close($curl);
            return $output;
}




function  sysconfig($key){
     
      if(config('cache.open_redis')){ //系统开启配置reids
                $result=\think\facade\Cache::store('redis')->handler()->hGet('config',$key);    
                if(empty($result)){
                    $result=\think\facade\Db::name('config')->where('config_key',$key)->value('config_value');
                    //echo $result;die();
                }
      }else{
          $result=\think\facade\Db::name('config')->where('config_key',$key)->value('config_value');
      }
     
      return $result;

}


function  getOrderNo(){

    $str = date('Ymd').substr(implode(NULL, array_map('ord', str_split(substr(uniqid(), 7, 13), 1))), 0, 8);
    return $str;
}


function  new_apikey(){ 

          $chars='ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz';
          $string=time();
          for($len=8;$len>=1;$len--)
          {
              $position=mt_rand()%strlen($chars);
              $position2=mt_rand()%strlen($string);
              $string=substr_replace($string,substr($chars,$position,1),$position2,0);
        }
         return $string;
}


function  new_rand_code($n){

              $code = 'abcdefghijklmnopqrstuvwxyz';
              $rand = $code[rand(0,25)]
                  .strtoupper(dechex(date('m')))
                  .date('d').substr(time(),-5)
                  .substr(microtime(),2,5)
                  .sprintf('%02d',rand(0,99));


              for(
                  $a = md5( $rand, true ),
                  $s = '0123456789abcdefghijklmnopqrstuvwxyz',
                  $d = '',
                  $f = 0;
                  $f < $n;
                  $g = ord( $a[ $f ] ),
                  $d .= $s[ ( $g ^ ord( $a[ $f + 16-$n ] ) ) - $g & 0x1F ],
                  $f++
              );
              $d=str_split($d);
              foreach ($d as $k => &$v) {
                    $v=rand(0,1)?strtoupper($v):$v;
              }
              return  implode('',$d);
}


function get_ip(){
   
        $ip = '';
        if (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $arr    =   explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
            $pos    =   array_search('unknown',$arr);
            if(false !== $pos) unset($arr[$pos]);
            $ip     =   trim($arr[0]);
        }elseif (isset($_SERVER['REMOTE_ADDR'])) {
            $ip     =   $_SERVER['REMOTE_ADDR'];
        }
     
}



function applyflow_add($applyid,$operateid,$remark,$status,$time){
   
        $data=[
            'apply_id'=>$applyid,
            'operateid'=>$operateid,
            'remark'=>$remark,
            'status'=>$status,
            'update_time'=>$time
        ];

        $result=Db::name('apply_flow')->insert($data);

        if($result){
          return  true;
        }else{
          return  false;
        }
     
}




function mbpoint_format($v) {
     $number = floatval(sprintf("%.2f", $v));
     return $number;
}



/**
 * 结果格式的统一返回
 */
function result($data = [], int $code = 1, $msg = 'ok', string $type = '', array $header = []): Response
{
    $result = [
        'code' => $code,
        'msg' => $msg,
        'data' => $data
    ];
    $type = $type ?: 'json';
    $response = Response::create($result, $type)
        ->header($header);

    throw new HttpResponseException($response);
}

