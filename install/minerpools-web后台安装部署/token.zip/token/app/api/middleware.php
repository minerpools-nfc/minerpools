<?php
return [
      \app\api\middleware\AllowCrossDomain::class
];
