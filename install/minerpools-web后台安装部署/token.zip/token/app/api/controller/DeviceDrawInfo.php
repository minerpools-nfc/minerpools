<?php
namespace app\api\controller;


use app\api\validate\ID;
use think\App;
use think\facade\Db;
use think\facade\Request;
use app\api\service\JwtAuth;
use think\Response;
use app\common\model\DeviceDrawInfo as DeviceDrawInfoModel;

class DeviceDrawInfo extends ABase
{

    protected $middleware = [
        'app\api\middleware\Api' => [],
    ];


    public function __construct(App $app)
    {
        parent::__construct($app);
    
    }





     public function index()
    {
        

        $pageNum=  Request::param('pageNum',1);
        $pageSize= Request::param('pageSize', config('app.page_size'));

        $lists=DeviceDrawInfoModel::pageList($pageNum,$pageSize,$field='drawid,draw_name,drawid_type,startime,endtime,total_num,device_num,draw_status',[],['updatetime'=>'desc']);


        $data=[
            'table'=>[
                 "page"=>$pageNum,
                 "pageSize"=>$pageSize,
                 "rows" =>$lists['tablelist'],
                 "total"=>$lists['total'],
             ]
        ];



        return $this->result($data, 1, '');

    }

  
   public function add(){


          $data = Request::except(['file'], 'post');

          //print_r($data);die();

         $draw_name=input('draw_name');
         $drawid_type=input('drawid_type');
         $total_num=input('total_num');
         $startime=input('startime');
         $endtime=input('endtime');

         $devices_type=input('devices_type');


         if(empty($draw_name)||empty($drawid_type)||empty($total_num)){
             $this->result([], 0, '名称/类型/分红总额不能为空!');
        }

        if($drawid_type==2){
                if(empty($startime)||empty($endtime)){
                    $this->result([], 0, '开始和结束日期不能为空!');
                 }
        }


        $id =DeviceDrawInfoModel::where('draw_name', '=', $draw_name)->find();
        if ($id) {
            $this->result([], 0, '该名称已存在');
        }

        $where=[];
        if($devices_type==0){ //所有矿机
                $where[]=['devicestatus','in',[1,2]];               
        }else{ //分红矿机
             $where[]=['devicestatus','in',[1,2]];    
             $where[]=['typeid','=',$devices_type]; 
        }      

        $devices_obj=Db::name('devices')->where($where)->field('devicesn,wallet_address')->select()->toArray();
        $devices_num=count($devices_obj);

        if($drawid_type==1){//平均               
                
                 $draw_rate=sprintf("%.4f",1/$devices_num);
                 $draw_num=sprintf("%.8f",$total_num/$devices_num);
        }
        
        if($drawid_type==2){//按流量 先计算总比例数

            $devicesns=[];

            foreach ($devices_obj as $key => $device) {
                  array_push($devicesns,$device['devicesn']);
            }
            $allsum=Db::name('device_nfc_record')->where('devicesn','in', $devicesns)->whereBetweenTime('ctime', $startime,$endtime)->sum('nfc_num');             
        }


        $data['draw_status']=3;
        $data['device_num']=$devices_num;
        $data['drawid']=new_rand_code(12);           
        $data['addtime']  =date('Y-m-d H:i:s');
        $data['addby']    =$this->getUid();
        $data['updatetime']=date('Y-m-d H:i:s');
        $data['updateby']=$this->getUid();

    
         unset($data['devices_type']);
   
        
          if($drawid_type==1){               
                unset($data['startime']);
                unset($data['endtime']);
          }

       Db::startTrans();
       try {
            $id=DeviceDrawInfoModel::insertGetId($data);

            $detaildata=[];
            foreach ($devices_obj as $key => $device) {

                 if($drawid_type==2){//按流量
                    $onesum=Db::name('device_nfc_record')->where('devicesn','=', $device['devicesn'])->whereBetweenTime('ctime', $startime,$endtime)->sum('nfc_num');
                    if($allsum>0){
                          $draw_rate=sprintf("%.4f", $onesum/$allsum);
                          $draw_num=sprintf("%.8f",$total_num*$draw_rate);
                    }else{//全部没有流量回归平均
                          $draw_rate=sprintf("%.4f",1/$devices_num);
                          $draw_num=sprintf("%.4f",$total_num/$devices_num);
                    }
                  
                 }

                 $detaildata[]=[
                        'detailid'=>new_rand_code(12),
                        'drawid'=>$data['drawid'],
                        'devicesn'=>$device['devicesn'],
                        'draw_rate'=>$draw_rate,
                        'draw_num'=>$draw_num,
                        'draw_address'=>$device['wallet_address']?$device['wallet_address']:'',
                        'draw_transFlag'=>6,
                        'instime'=>date('Y-m-d H:i:s'),           
                   ];
            }

            Db::name('device_draw_detail')->insertAll($detaildata);        
           Db::commit();
        } catch (\Exception $e) {

            Db::rollback();
            $this->result([], 0, '添加失败');
        }

        $this->result([], 1, '添加成功');

    }



     public function getone(){
            
                $sn=Request::param('drawid');
                $field='drawid,draw_name,drawid_type,startime,endtime,total_num';
                $data=DeviceDrawInfoModel::getOne(['drawid'=>$sn],$field);         

                 return  $this->result($data);

    }

   // public function edit(){


   //       $data = Request::except(['file'], 'post');


   //       $draw_id=input('drawid');
   //       $draw_name=input('draw_name');
   //       $drawid_type=input('drawid_type');
   //       $total_num=input('total_num');
   //       $startime=input('startime');
   //       $endtime=input('endtime');

   //       $devices_type=input('devices_type');


   //       if(empty($draw_id)||empty($draw_name)||empty($drawid_type)||empty($total_num)){
   //           $this->result([], 0, '编号/名称/类型/分红总额不能为空!');
   //      }

   //      $draw=DeviceDrawInfoModel::where('drawid',$draw_id)->find();
   //      if(!$draw){
   //           $this->result([], 0, '你要修改的记录不存在!');
   //      }
   //      if($draw['draw_status']!=3){
   //          $this->result([], 0, '该记录当前你不能修改!');
   //      }


   //      if($drawid_type==2){
   //              if(empty($startime)||empty($endtime)){
   //                  $this->result([], 0, '开始和结束日期不能为空!');
   //               }
   //      }


   //      $fdraw =DeviceDrawInfoModel::where('draw_name', '=', $draw_name)->find();
   //      if ($fdraw&&$fdraw['drawid']!=$draw['drawid']) {
   //          $this->result([], 0, '该名称已存在');
   //      }

   //      $where=[];
   //      if($devices_type==0){ //所有矿机
   //              $where[]=['devicestatus','in',[1,2]];               
   //      }else{ //分红矿机
   //           $where[]=['devicestatus','in',[1,2]];    
   //           $where[]=['typeid','=',$devices_type]; 
   //      }      

   //      $devices_obj=Db::name('devices')->where($where)->field('devicesn,wallet_address')->select()->toArray();
   //      $devices_num=count($devices_obj);

   //      if($drawid_type==1){//平均               
                
   //               $draw_rate=sprintf("%.4f",1/$devices_num);
   //               $draw_num=sprintf("%.8f",$total_num/$devices_num);
   //      }
        
   //      if($drawid_type==2){//按流量 先计算总比例数

   //          $devicesns=[];

   //          foreach ($devices_obj as $key => $device) {
   //                array_push($devicesns,$device['devicesn']);
   //          }
   //          $allsum=Db::name('device_nfc_record')->where('devicesn','in', $devicesns)->whereBetweenTime('ctime', $startime,$endtime)->sum('nfc_num');             
   //      }



   //   //   $data['draw_status']=0;
   //      $data['device_num']=$devices_num;
   //  //   $data['drawid']=new_rand_code(10);           
   //   //   $data['addtime']  =date('Y-m-d H:i:s');
   //   //   $data['addby']    =$this->getUid();
   //      $data['updatetime']=date('Y-m-d H:i:s');
   //      $data['updateby']=$this->getUid();

   //       if($drawid_type==1){
           
   //              unset($data['startime']);
   //              unset($data['endtime']);
   //        }
   //      if($drawid_type==2){
   //               unset($data['devices_type']);
   //       }  


   //      Db::startTrans();
   //      try {
   //          $id=DeviceDrawInfoModel::editSave($data);

   //          Db::name('device_draw_detail')->where('drawid',$draw_id)->delete();

   //          $detaildata=[];
   //          foreach ($devices_obj as $key => $device) {

   //               if($drawid_type==2){//按流量
   //                  $onesum=Db::name('device_nfc_record')->where('devicesn','=', $device['devicesn'])->whereBetweenTime('ctime', $startime,$endtime)->sum('nfc_num');
   //                  if($allsum>0){
   //                        $draw_rate=sprintf("%.4f",$onesum/$allsum);
   //                        $draw_num=sprintf("%.8f",$total_num*$draw_rate);
   //                  }else{//全部没有流量回归平均
   //                        $draw_rate=sprintf("%.4f",1/$devices_num);
   //                        $draw_num=sprintf("%.8f",$total_num/$devices_num);
   //                  }
                  
   //               }

   //               $detaildata[]=[
   //                      'detailid'=>new_rand_code(12),
   //                      'drawid'=>$data['drawid'],
   //                      'devicesn'=>$device['devicesn'],
   //                      'draw_rate'=>$draw_rate,
   //                      'draw_num'=>$draw_num,
   //                      'draw_address'=>$device['wallet_address']?$device['wallet_address']:'',
   //                      'draw_transFlag'=>6,
   //                      'updatetime'=>date('Y-m-d H:i:s'),           
   //                 ];
   //          }

   //          Db::name('device_draw_detail')->insertAll($detaildata);        
   //         Db::commit();
   //      } catch (\Exception $e) {

   //          Db::rollback();
   //          $this->result([], 0, '修改失败');
   //      }

   //      $this->result([], 1, '修改成功');

   //  }





     public function delete()
     {

        $drawid=input('drawid'); 

         if(empty($drawid)){
             $this->result([], 0, '参数错误！');
        }

        $draw=DeviceDrawInfoModel::where('drawid',$drawid)->find();
        if(!$draw){
             $this->result([], 0, '错误,要删除的记录不存在!');
        }
        if($draw['draw_status']!=3){
            $this->result([], 0, '该记录不能删除!');
        }
        if (Request::isPost()) {                      
                

                  Db::startTrans();
                    try {

                       //  Db::name('device_draw_detail')->where('drawid',$drawid)->delete();
                         $result=DeviceDrawInfoModel::del($drawid);

                          Db::commit();

                    } catch (\Exception $e) {

                        Db::rollback();
                        $this->result([], 0, '出错,稍后重试！');
                    }

                    return $this->result($result);

           
        }

      



    }


}
