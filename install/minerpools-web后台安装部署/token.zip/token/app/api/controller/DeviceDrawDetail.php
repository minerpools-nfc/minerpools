<?php
namespace app\api\controller;


use app\api\validate\ID;
use think\App;
use think\facade\Db;
use think\facade\Request;
use app\api\service\JwtAuth;
use think\Response;
use app\common\model\DeviceDrawDetail as DeviceDrawDetailModel;
use app\common\model\DeviceDrawInfo as DeviceDrawInfoModel;

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;


class DeviceDrawDetail extends ABase
{

    protected $middleware = [
        'app\api\middleware\Api' => [],
    ];


    public function __construct(App $app)
    {
        parent::__construct($app);
    
    }


    //  public function index()
    // {
        

    //     $pageNum=  Request::param('pageNum',1);
    //     $pageSize= Request::param('pageSize', config('app.page_size'));
    //     $policyid=Request::param('policyid');
    //     $draw_status=Request::param('draw_status');

    //     $ctime=Request::param('ctime');

    //     $where=[];

    //     if(!empty($ctime)){

    //             $where[]=['ctime','=',$ctime];    
    //     }


    //      if(isset($draw_status)){
    //             if($draw_status===0){
    //                 $where[]=['draw_status','=',0];
    //             }

    //             if($draw_status==1){
    //                 $where[]=['draw_status','=',1];
    //             }

    //             if($draw_status==2){
    //                 $where[]=['draw_status','=',2];
    //             }            
    //      }


    //       if(!empty($policyid)){

    //             $where[]=['policyid','=',$policyid];    
    //       }                   

    //         $order=['ctime'=>'desc'];
    //         $field='dayid,ctime,policyid,devicenum,nfc_num,draw_status,fail_num';
    //         $data=DeviceDrawDayModel::pageList($pageNum,$pageSize,$field,$where,$order);
          
    //         return $this->result($data, 1, '');
    // }

     public function preall(){
      
   
        $drawid=Request::param('drawid');
        if(empty($drawid)){
               $this->result([], 0, '参数错误!');
        }
   
        $where[]=['drawid','=',$drawid];
        $order=['draw_transFlag'=>'desc'];
        $field='detailid,devicesn,draw_rate,draw_num,draw_transFlag,draw_address';
        $data =Db::name('device_draw_detail')->where($where)->field($field)->order($order)->select()->toArray();  


         foreach ($data as $k => &$v) {

                if($v["draw_transFlag"] == 1)  $v["draw_status_label"] = "待转账";
                if($v["draw_transFlag"] == 2)  $v["draw_status_label"] = "转账交易中";
                if($v["draw_transFlag"] == 3)  $v["draw_status_label"] = "转账成功";
                if($v["draw_transFlag"] == 4)  $v["draw_status_label"] = "转账失败";
                if($v["draw_transFlag"] == 5)  $v["draw_status_label"] = "划转中";
                if($v["draw_transFlag"] == 6)  $v["draw_status_label"] = "待执行";
         
         } 
      
        return $this->result($data, 1, '');

    }






     public function predevices(){
      

        $pageNum=  Request::param('pageNum',1);
        $pageSize= Request::param('pageSize', config('app.page_size'));
        $devicesn=Request::param('devicesn');
        // $draw_address=Request::param('draw_address');
        // $draw_transFlag=Request::param('draw_transFlag');

        $device_status=Request::param('device_status');
        $device_type=Request::param('device_type');

    
        $drawid=Request::param('drawid');
        if(empty($drawid)){
               $this->result([], 0, '参数错误!');
        }
   
        $where[]=['drawid','=',$drawid];

         if($device_status==1||$device_status===0){
               $where[]=['online_status','=',$device_status];
        }
        if(!empty($devicesn)){
               $where[]=['a.devicesn','=',$devicesn];
        }
         if(!empty($device_type)){
               $where[]=['typeid','=',$device_type];
        }



        $order=['draw_transFlag'=>'desc'];
        $field='detailid,a.devicesn,draw_rate,draw_num,draw_transFlag,draw_address,typeid';
   //     $lists=DeviceDrawDetailModel::pageList($pageNum,$pageSize,$field,$where,$order);


        $lists=Db::name('device_draw_detail')->alias('a')->join('devices w','a.devicesn=w.devicesn')->where($where)->field($field)->order($order)->page($pageNum,$pageSize)->select()->toArray();  
         foreach ($lists as $k =>$v) {
                $typename=Db::name('devices_type')->where('id',$v['typeid'])->value('name');
                if($typename){
                    $lists[$k]['typename']=$typename;          
                }else{
                    $lists[$k]['typename']='';          
                }
                if($v["draw_transFlag"] == 1)  $lists[$k]["draw_status_label"] = "待转账";
                if($v["draw_transFlag"] == 2)  $lists[$k]["draw_status_label"] = "转账交易中";
                if($v["draw_transFlag"] == 3)  $lists[$k]["draw_status_label"] = "转账成功";
                if($v["draw_transFlag"] == 4)  $lists[$k]["draw_status_label"] = "转账失败";
                if($v["draw_transFlag"] == 5)  $lists[$k]["draw_status_label"] = "划转中";
                if($v["draw_transFlag"] == 6)  $lists[$k]["draw_status_label"] = "待执行";
                
         } 


         $total= Db::name('device_draw_detail')->alias('a')->join('devices w','a.devicesn=w.devicesn')->where($where)->field($field)->count();

      
        $data=[
            'table'=>[
                 "page"=>$pageNum,
                 "pageSize"=>$pageSize,
                 "rows" =>$lists,
                 "total"=> $total,
             ]
        ];



        return $this->result($data, 1, '');

    }



    //  public function resdevices(){
      

    //     $pageNum=  Request::param('pageNum',1);
    //     $pageSize= Request::param('pageSize', config('app.page_size'));
    //     $devicesn=Request::param('devicesn');
    // //    $draw_address=Request::param('draw_address');
    // //    $draw_transFlag=Request::param('draw_transFlag');
    
    //     $drawid=Request::param('drawid');
    //     if(empty($drawid)){
    //            $this->result([], 0, '参数错误!');
    //     }
   
    //     $where[]=['drawid','=',$drawid];
    //     $order=['devicesn'=>'desc'];
    //     $field='detailid,devicesn,draw_rate,draw_num,draw_address,draw_transFlag,draw_time';
    //     $lists=DeviceDrawDetailModel::pageList($pageNum,$pageSize,$field,$where,$order);
      
    //     $data=[
    //         'table'=>[
    //              "page"=>$pageNum,
    //              "pageSize"=>$pageSize,
    //              "rows" =>$lists['tablelist'],
    //              "total"=>$lists['total'],
    //          ]
    //     ];

    //     return $this->result($data, 1, '');

    // }





      public function canadd()
    {
        
        $typeid=input('typeid');
        $drawid=input('drawid');
        $pageNum=  Request::param('pageNum',0);
        $pageSize= Request::param('pageSize', config('app.page_size'));
        $device_status=Request::param('device_status');
        $where=[];
        if(!empty($typeid)){
             $where[]=['typeid','=',$typeid];
         }
         if(!empty($drawid)){
            // $where[]=['drawid','=',$drawid];

             $devicesns=Db::name('device_draw_detail')->where('drawid',$drawid)->column('devicesn');
          //   print_r($devicesns);die();
             $where[]=['devicesn','not in',$devicesns];

         }
          if($device_status==1||$device_status===0){
               $where[]=['online_status','=',$device_status];
        }

   
        $order=['createtime'=>'desc'];
        $field='devicesn,online_status,typeid';
    //    $lists=DevicesModel::pageList($pageNum,$pageSize,$field,$where,$order,$haswhere);
        $where[]=['devicestatus','=',1];


        if($pageNum>0){
               $lists=Db::name('devices')->where($where)->field($field)->order($order)->page($pageNum,$pageSize)->select()->toArray();  
        }else{
            $lists=Db::name('devices')->where($where)->field($field)->order($order)->select()->toArray();  
        }


        // foreach ($lists as $k =>$v) {
        //         $typename=Db::name('devices_type')->where('id',$v['typeid'])->value('name');
        //         if($typename){
        //             $lists[$k]['typename']=$typename;          
        //         }else{
        //             $lists[$k]['typename']='';          
        //         }
                
        //  } 

       $total=Db::name('devices')->where($where)->field($field)->count();

      
        $data=[
            'table'=>[
                 "page"=>$pageNum,
                 "pageSize"=>$pageSize,
                 "rows" =>$lists,
                 "total"=> $total,
             ]
        ];
       
        return $this->result($data, 1, '');
    }



     public function savecoinone(){
      

       if (Request::isPost()) {       

               $data = Request::except(['file'], 'post');     
               if(empty($data['detailid'])||empty($data['draw_num'])||empty($data['drawid'])) {
                    $this->result([], 0, '参数错误!');
               }
       

              $total=DeviceDrawInfoModel::where(['drawid'=>$data['drawid']])->value('total_num');

              $detail=DeviceDrawDetailModel::where(['detailid'=>$data['detailid']])->find();  

               if($detail['draw_transFlag']==2||$detail['draw_transFlag']==3||$detail['draw_transFlag']==5){
                     $this->result([], 0, '该记录你当前不能修改!');
               }

              // $where1=[
              //       ['drawid','=',$data['drawid']],
              //       ['detailid','<>',$data['detailid']]
              // ];
           
              // $othersum=DeviceDrawDetailModel::where($where1)->value('draw_num');

              // $newsum=$othersum+$data['draw_num'];

              // if($newsum>$total){
              //     $this->result([], 0, '要分配的总数超过分红总额,请修改!');
              // }


               // $new_rate=sprintf("%.4f",$data['draw_num']/$total);

                $indata=[
                    'detailid'=>$data['detailid'],
                  //  'draw_rate'=>$new_rate,
                    'draw_num'=>$data['draw_num'],
                    'updatetime'=>date('Y-m-d H:i:s')
                ];
          
                $result =DeviceDrawDetailModel::editSave($indata);
       
                return  $this->result($result);
        }
    }



    public function addcoinone(){
      

       if (Request::isPost()) {       

               $data = Request::except(['file'], 'post');     
               if(empty($data['draw_num'])||empty($data['devicesn'])||empty($data['drawid'])) {
                    $this->result([], 0, '参数错误!');
               }
       


              // $total=DeviceDrawInfoModel::where(['drawid'=>$data['drawid']])->value('total_num');

             
              // $where1=[
              //       ['drawid','=',$data['drawid']],
              //       ['detailid','<>',$data['detailid']]
              // ];
           
              // $othersum=DeviceDrawDetailModel::where($where1)->value('draw_num');

              // $newsum=$othersum+$data['draw_num'];

              // if($newsum>$total){
              //     $this->result([], 0, '要分配的总数超过分红总额,请修改!');
              // }
               $wallet_address=Db::name('devices')->where('devicesn',$data['devicesn'])->value('wallet_address');




                $indata=[
                   'detailid'=>new_rand_code(12),
                    'drawid'=>$data['drawid'],
                    'devicesn'=>$data['devicesn'],
                    'draw_num'=>$data['draw_num'],
                    'draw_address'=>$wallet_address?$wallet_address:'',
                    'draw_transFlag'=>6,
                    'instime'=>date('Y-m-d H:i:s'), 
                ];
          
                $result =DeviceDrawDetailModel::addSave($indata);
       
                return  $this->result($result);
        }
    }




     public function deletecoin(){
      

       if (Request::isPost()) {       

               $data = Request::except(['file'], 'post');    
               if(empty($data['detailid'])) {
                    $this->result([], 0, '参数错误!');
               }
               $detail=DeviceDrawDetailModel::where(['detailid'=>$data['detailid']])->find();  
              if(!$detail){
                   $this->result([], 0, '该记录不存在!');
               }


               if($detail['draw_transFlag']==2||$detail['draw_transFlag']==3||$detail['draw_transFlag']==5){
                   $this->result([], 0, '该记录不能删除!');
               }
 
              $result=DeviceDrawDetailModel::where(['detailid'=>$data['detailid']])->delete();  

              if($result){
                         $this->result([], 1, '删除成功!');
              }

        }
    }





     public function savecoinmore(){
      

     

               $data = Request::except(['file'], 'post');     
               if(empty($data['drawid'])||empty($data['details'])||!is_array($data['details'])) {
                    $this->result([], 0, '参数错误!');
               }       

              foreach ($data['details']  as $detail) {
                      $detail=DeviceDrawDetailModel::where(['detailid'=>$detail['detailid']])->find();  
                      if($detail['draw_transFlag']!=6){
                                 $this->result([], 0, '存在不能修改的记录!');
                      }
                       $editarr[]=[                      
                        'drawid'=>$data['drawid'],
                        'detailid'=>$detail['detailid'],
                        'draw_num'=>$detail['draw_num'],                    
                        'updatetime'=>date('Y-m-d H:i:s'),           
                     ];
              }

               foreach ($data['adds']  as $detail) {      
                     $wallet_address=Db::name('devices')->where('devicesn',$detail['devicesn'])->value('wallet_address');           
                      $addarr[]=[
                        'detailid'=>new_rand_code(12),
                        'drawid'=>$data['drawid'],
                        'devicesn'=>$detail['devicesn'],
                        'draw_num'=>$detail['draw_num'],                    
                        'draw_address'=>$wallet_address,
                        'draw_transFlag'=>6,
                        'instime'=>date('Y-m-d H:i:s'),           
                    ];
               }


                  Db::startTrans();
                 try {

               

                    Db::name('device_draw_detail')->saveAll($editarr);

                    Db::name('device_draw_detail')->insertAll($addarr);      


                     Db::commit();
                  } catch (\Exception $e) {

                      Db::rollback();
                      $this->result([], 0, '添加失败');
                  }

                  $this->result([], 1, '添加成功');


    }




     public function docoin(){


               $data = Request::except(['file'], 'post');     
               if(empty($data['drawid'])||empty($data['prikey'])) {
                    $this->result([], 0, '参数错误!');
               }       
                Db::startTrans();
                 try {

                  Db::name('device_draw_info')->where(['drawid'=>$data['drawid'],'draw_status'=>3])->update(['draw_status'=>0]);
                  Db::name('device_draw_detail')->where(['drawid'=>$data['drawid'],'draw_transFlag'=>6])->update(['draw_transFlag'=>1]);
                  $sum=Db::name('device_draw_detail')->where(['drawid'=>$data['drawid']])->sum('draw_num');
                //  $count=Db::name('device_draw_detail')->where(['drawid'=>$data['drawid']])->count();

                  $details=Db::name('device_draw_detail')->where(['drawid'=>$data['drawid']])->select();
                  $count=count($details);
                  $detaildata=[];
                  if($count&&$sum){

                                foreach ($details as $key => $detail) {

                                         $draw_rate=sprintf("%.4f", $detail['draw_num']/$sum);
                                         $detaildata[]=[                                                
                                                    'detailid'=>$detail['detailid'],                                                
                                                    'draw_rate'=>$draw_rate,                                                  
                                                    'updatetime'=>date('Y-m-d H:i:s'),           
                                               ];
                            
                                 }
                        
                    }

                   $nd=new  DeviceDrawDetailModel();
                   $nd->saveAll($detaildata);   
                   Db::name('device_draw_info')->where(['drawid'=>$data['drawid']])->update(['total_num'=> $sum,'device_num'=>$count]);
                   Db::commit();
               } catch (\Exception $e) {                     
                      Db::rollback();
                      // print_r($e->getMessage());die();
                      $this->result([], 0, '操作失败!');
              }



            //  $data=[

            //  "drawid"=>$data['drawid'],

            //   "prikey"=>""

            // ];
         
            $url="";

           $postdata='{"drawid":"'.$data['drawid'].'","prikey":"'.$data['prikey'].'"}';    

          $result=curl_request($url,$postdata,$method='POST_JSON');

          $result=json_decode($result,true);






          if($result['result']===0){
                   $this->result([], 1, $result['errmsg']);
          }else{
                   $this->result([], 0, $result['errmsg']);
          } 

     }





     public function export(){

                  $drawid=input('drawid');            
                  if(empty($drawid)){
                        $this->result([], 0, '参数错误!');
                   }
             
                  $spreadsheet = new Spreadsheet();
                  $sheet = $spreadsheet->getActiveSheet();

                  $drawname=Db::name('device_draw_info')->where('drawid',$drawid)->value('draw_name');  
                  $lists=Db::name('device_draw_detail')->where('drawid',$drawid)->select()->toArray();  



                   $sheet->setCellValue('A1', '矿机sn');
                   $sheet->setCellValue('B1', '分红比例');
                   $sheet->setCellValue('C1', '分红数量(NFC)');
                   $sheet->setCellValue('D1', '分红发放地址');
                   $sheet->setCellValue('E1', '分红发放时间');
                   $sheet->setCellValue('F1', '分红转账结果');
                   $sheet->setCellValue('G1', '更新时间');
                  


                  foreach ($lists as $key => $detail) {

                            if($detail["draw_transFlag"] == 1)  $statusflag = "待转账";
                            if($detail["draw_transFlag"] == 2)  $statusflag = "转账交易中";
                            if($detail["draw_transFlag"] == 3)  $statusflag = "转账成功";
                            if($detail["draw_transFlag"] == 4)  $statusflag = "转账失败";
                            if($detail["draw_transFlag"] == 5)  $statusflag = "划转中";
                            if($detail["draw_transFlag"] == 6)  $statusflag = "待执行";
                   
                       $sheet->setCellValue('A'.($key+2), $detail['devicesn']);
                       $sheet->setCellValue('B'.($key+2), ($detail['draw_rate']*100).'%');
                       $sheet->setCellValue('C'.($key+2), $detail['draw_num']);
                       $sheet->setCellValue('D'.($key+2), $detail['draw_address']);
                       $sheet->setCellValue('E'.($key+2), $detail['draw_time']);
                       $sheet->setCellValue('F'.($key+2), $statusflag);
                       $sheet->setCellValue('G'.($key+2), $detail['updatetime']);
                     
                  }
                  $writer = new Xlsx($spreadsheet);     
                  $filename='分红导出-'.$drawname.'-'.date('YmdHis'). '.xlsx';
                  $writer->save(public_path().'uploads/excel/'.$filename);


                  $path=Request::domain().'/uploads/excel/'.$filename;

                  $this->result($path, 1, '导出成功!');

                  // header('Content-Type: application/vnd.ms-excel');
                  // header('Content-Disposition: attachment;filename='.$filename);
                  // header('Cache-Control: max-age=0');
                             
                  //    $writer->save('php://output');



     }



}
