<?php
namespace app\api\controller;


use app\api\validate\ID;
use app\common\validate\UserStatus;
use think\App;
use think\facade\Db;
use think\facade\Request;
use app\api\service\JwtAuth;
use think\Response;
use app\common\model\BindUsers as BindUsersModel;

class BindUsers extends ABase
{

    protected $middleware = [
        'app\api\middleware\Api' => ['except' => ['login']],
    ];


    public function __construct(App $app)
    {
        parent::__construct($app);
    
    }



    public function login()
    {
      
         $username=input('username');
         $password=input('password');
         if(empty($username)||empty($password)){
             $this->result([], 0, '用户名和密码不能为空!');
        }
        $user = BindUsersModel::where('loginname', $username)
            ->where('loginpwd',md5($password))
            ->find();
        if (empty($user)) {
            $this->result([], 0, '帐号或密码错误');
        } else {
            if ($user['user_status'] == 0) {
   
                $jwtAuth = JwtAuth::getInstance();
                $token = $jwtAuth->setUid($user['userid'])->encode()->getToken();
                $data=[
                    'userid'=>$user['userid'],
                    'username'=>$user['firstname'],
                    'token' => $token
                ];


                $this->result($data, 1, '登录成功');
            } else {
                $this->result([], 0, '用户已被锁定,请联系管理员');
            }
        }
    }



  
     public function index()
    {
        $pageNum=  Request::param('pageNum',1);
        $pageSize= Request::param('pageSize', config('app.page_size'));


        $lowmbpoit=Request::param('lowmbpoit');
        $wallet_address=Request::param('wallet_address');
       // var_dump($wallet_address);die();
         $deleteflag=Request::param('deleteflag');

        $search=Request::param('search');

        $user_status=Request::param('user_status');

      

        $where='1';
     
        if(!empty($search)){
             $where.=' and ( loginname like "%'.$search.'%" or lastname like "%'.$search.'%" or firstname like "%'.$search.'%" or phone like "%'.$search.'%" or email like "%'.$search.'%")';
         }


          if(!empty($wallet_address)){
            
              if($wallet_address==1){
                 $where.=' and  wallet_address is null';
              }else{
                 $where.=' and  wallet_address="'.$wallet_address.'"';
              }
           
         }


           if(strlen($user_status)){
            
              if($user_status==0){
                 $where.=' and  user_status=0';
              }else{
                 $where.=' and  user_status<>0';
              }
           
         }

          if(!empty($deleteflag)){
 
                 $where.=' and  deleteflag!=1';
                       
         }else{
                $where.=' and  deleteflag=1';      
         }



          // $fromuser=Db::name('dpool_interface')->where('interid',1)->value('username');
          // $fromuserid=Db::name('bind_users')->where('loginname',$fromuser)->value('userid');
          // if($fromuserid){
          //   $where.=' and userid!='.$fromuserid;
          // }


     

      //  $lowmbpoit_num=Db::name('device_alarm_config')->where('cfgid',1)->value('mbpoint');
        if(!empty($lowmbpoit)){
                if($lowmbpoit==1){
                     $where.=' and mbpoint_alarm=1';
                }
                 if($lowmbpoit==2){
                       $where.=' and mbpoint_alarm=0';
                }
       }

          $field='userid,loginname,nickname,firstname,lastname,phone,email,mbpoint,user_status,mbpoint_alarm,wallet_address,deleteflag,updatetime';
          $total= Db::name('bind_users')->whereRaw($where)->count();
          $tablelist = Db::name('bind_users')->whereRaw($where)->field($field)->page($pageNum,$pageSize)->select()->toArray();  


         foreach($tablelist as $k => $v) {

              $deviceno=Db::name('devices')->where('delete_flag',1)->where('owerid',$tablelist[$k]["userid"])->count();
              $tablelist[$k]["device_no"] = $deviceno;
               $tablelist[$k]["mbpoint"]= mbpoint_format($v['mbpoint']);
         } 

 

         $data=[
            'table'=>[
                 "page"=>$pageNum,
                 "pageSize"=>$pageSize,
                 "rows" =>$tablelist,
                 "total"=>$total,
             ]
        ];
      
        return $this->result($data, 1, '');    
    }

  


   public function indexstatic(){

               

                 $plat_user=Db::name('dpool_interface')->where('interid',1)->value('username');
                 $plat_mbpoint=Db::name('bind_users')->where('loginname',$plat_user)->value('mbpoint');
        
                 $plat_user_num=Db::name('bind_users')->count();
                 $plat_low_mbpoint_user_num=Db::name('bind_users')->where('mbpoint_alarm',1)->count();

                 $data=[
                    'plat_mbpoint'=> mbpoint_format($plat_mbpoint),
                    'plat_user_num'=> $plat_user_num,
                    'plat_low_mbpoint_user_num'=>$plat_low_mbpoint_user_num
                 ];


                 $this->result($data,1,'');



   }



   
    public function transcalc(){

         $mbpoint=input('mbpoint');
         $userids=input('userids');
         $type=input('type') ;

        if(empty($mbpoint)||empty($userids)||empty($type)){
             $this->result([], 0, '参数错误!');
        }


        $userids_arr=explode(',',$userids);
        $field='userid,loginname,nickname,firstname,lastname,phone,email,mbpoint';
        $users=Db::name('bind_users')->where('userid','in',$userids_arr)->field($field)->select()->toArray();  

        if(!count($users)){
            $this->result([], 0, '错误,没有找到要分配的用户信息!');                
        }


          $plat_user=Db::name('dpool_interface')->where('interid',1)->value('username');
          $plat_mbpoint=Db::name('bind_users')->where('loginname',$plat_user)->value('mbpoint');



        
        if($type==1){//平均


               if($plat_mbpoint<$mbpoint){
                     $this->result([], 0, '积分余额不够,不能转出!');
               }

                $givenum=(float)sprintf("%.8f",$mbpoint/count($users));
        }

        if($type==2){//每个人
                 $givenum=(float)$mbpoint;
                if($plat_mbpoint<$mbpoint*count($users)){
                     $this->result([], 0, '积分余额不够,不能转出!');
               }

        }


         foreach($users as $k => $v) {

              $users[$k]["give_num"] =$givenum;
              $users[$k]["mbpoint"] =mbpoint_format($users[$k]["mbpoint"]);
         } 

         return $this->result($users, 1, '');
        
    }



 



    public function dotrans(){


          $datas = Request::except(['file'], 'post');
            if(empty($datas)||!is_array($datas)){
                 $this->result([], 0, '提交数据错误,请检查!');
            }

            $indata=[];

          $fromuser=Db::name('dpool_interface')->where('interid',1)->value('username');
          $fromuserid=Db::name('bind_users')->where('loginname',$fromuser)->value('userid');

          $mtbutch=new_rand_code(15);

          foreach ($datas   as $key => $value) {

                    $indata[]=[

                          'rdetailid'=>new_rand_code(12) ,
                          'fromuserid'=>$fromuserid?$fromuserid:0,
                          'touserid'=>$key,
                          'mbpoint'=>$value,
                          'transfer_status'=>1,
                          'instime'=>date('Y-m-d H:i:s'),
                          'updatetime'=>date('Y-m-d H:i:s'),
                          'mtbutch'=>$mtbutch
                    ];

          }

           $res=Db::name('user_mbpoit_record_detail')->insertAll($indata);   

            if ($res) {
                           list($msec, $sec) = explode(' ', microtime());
                           $msectime = (float)sprintf('%.0f', (floatval($msec) + floatval($sec)) * 1000);

                           $url="http://127.0.0.1:8446//v1/nfc/transfermbp?random=".$msectime;
                        //   $url="http://192.168.100.96:8446/v1/nfc/transfermbp?random=".$msectime;

                            $postdata='{"mtbutch":"'.$mtbutch.'"}';    
  
                            $result=curl_request($url,$postdata,$method='POST_JSON');
             
                            $result=json_decode($result,true);

                            if(array_key_exists('result', $result)){
                                  if($result['result']==0){
                                      $this->result([], 1, $result['errmsg']);
                                    //   $this->result([], 1, '提交成功,等待处理');
                                  }else{
                                      $this->result([], 0, $result['errmsg']);
                                  }
                            }else{
                                     $this->result([], 0, '操作失败,稍后重试');
                            }                           
 
            } else {
                      $this->result([], 1, '操作失败,稍后重试!');
            }


    }




    public function delete() //人工逻辑删除
     {
       
             $uid = $this->request->param('userid');

            if(empty($uid)){
                   $this->result([], 0, '参数错误!');
             }


            $user = BindUsersModel::where('userid', $uid)->find();
            if (!$user){
                return $this->result([], 0, '该用户不存在');
            }
            $user->deleteflag = 3;
            $user->user_status = 2;
            $user->save();
            return $this->result([], 1, '已成功移除');
    
    }




     public function setpassword(){
       
          if (Request::isPost()) {          
                  $data = Request::except(['file'], 'post');
                 if(empty($data['userid'])||empty($data['loginpwd'])){
                     $this->result([], 0, '参数错误!');
                }
                  
                   if(strlen($data['loginpwd']) < 6) {
                      $this->result([], 0, '密码长度不能低于6位');
                   }

                
                    $data['loginpwd']=md5($data['loginpwd']);
            
                    $result =BindUsersModel::editSave($data);
           
                    return  $this->result($result);
           } 

    }



    public function info(){

           $id=input('userid'); 
           if(empty($id)){
               $this->result([], 0, '参数错误!');
           }

            $field='userid,loginname,nickname,firstname,lastname,phone,email,mbpoint,mbpoint_alarm,user_status,wallet_address';

            $bind=Db::name('bind_users')->field($field)->where('userid',$id)->find();
            if(!$bind){
                $this->result([], 0, '该用户不存在!');
            }
            $bind['mbpoint']=mbpoint_format($bind['mbpoint']);

            return  $this->result($bind);

    }



     public function devices()
    {
        

        $pageNum=  Request::param('pageNum',1);
        $pageSize= Request::param('pageSize', config('app.page_size'));
    
        $owerid=Request::param('userid');

        if(empty($owerid)){
               $this->result([], 0, '参数错误!');
        }

        $where=[];
        $where[]=['owerid','=',$owerid];
       
     


        $order=['createtime'=>'desc'];
        $field='devicesn,online_status,online_time,offline_time,devicestatus,device_localtion';
  
        if($pageNum>0){
               $lists=Db::name('devices')->where($where)->field($field)->order($order)->page($pageNum,$pageSize)->select()->toArray(); 
        }else{
               $lists=Db::name('devices')->where($where)->field($field)->order($order)->select()->toArray();  
        }


        $total= Db::name('devices')->where($where)->count();

        $data=[
            'table'=>[
                 "page"=>$pageNum,
                 "pageSize"=>$pageSize,
                 "rows" =>$lists,
                 "total"=>$total,
             ]
        ];
      
        return $this->result($data, 1, '');
    }



     public function mbpoint()
    {
        

        $pageNum=  Request::param('pageNum',1);
        $pageSize= Request::param('pageSize', config('app.page_size'));
    
        $owerid=Request::param('userid');

        if(empty($owerid)){
               $this->result([], 0, '参数错误!');
        }

        $where=[];
        $where[]=['touserid','=',$owerid];
       
     


        $order=['updatetime'=>'desc'];
        $field='fromuserid,touserid,mbpoint,transfer_status,transfertime,faild_msg';
  
        if($pageNum>0){
               $lists=Db::name('user_mbpoit_record_detail')->where($where)->field($field)->order($order)->page($pageNum,$pageSize)->select()->toArray(); 
        }else{
               $lists=Db::name('user_mbpoit_record_detail')->where($where)->field($field)->order($order)->select()->toArray();  
        }


        $total= Db::name('user_mbpoit_record_detail')->where($where)->count();


         foreach ($lists as $k => &$v) {

             if($v["transfer_status"] == 1)  $v["transfer_status_label"] = "待转让";
             if($v["transfer_status"] == 2)  $v["transfer_status_label"] = "转让中";
             if($v["transfer_status"] == 3)  $v["transfer_status_label"] = "已转入";
             if($v["transfer_status"] == 4)  $v["transfer_status_label"] = "转让失败";


              $v['mbpoint']=mbpoint_format($v['mbpoint']);

              $v['fromusername']=Db::name('bind_users')->where('userid',$v['fromuserid'])->value('firstname');

         } 

        $data=[
            'table'=>[
                 "page"=>$pageNum,
                 "pageSize"=>$pageSize,
                 "rows" =>$lists,
                 "total"=>$total,
             ]
        ];
      
        return $this->result($data, 1, '');
    }

    /*
     * 更改用户状态
     */
    public function status(){
        (new UserStatus())->scene('status')->goCheck();

        $status = $this->request->param('status');
        $uid = $this->request->param('uid');
        $user = BindUsersModel::where('userid', $uid)->find();
        if (!$user){
            return $this->result([], 0, '该用户不存在');
        }
        $user->user_status = $status;
        $user->save();
        return $this->result();
    }

    /*
     * 修改钱包地址
     */
    public function modifyWallet(){
        (new UserStatus())->scene('address')->goCheck();
        $uid = $this->request->param('uid');
        $address = $this->request->param('address');

        $user = BindUsersModel::where('userid', $uid)->find();
        if (!$user){
            return $this->result([], 0, '该用户不存在');
        }
        $user->wallet_address = $address;
        $user->save();
        return $this->result();
    }



     public function myinfo(){  //app用户我的
       
          if (Request::isPost()) {     
                  $pdata = Request::except(['file'], 'post');
                  if(empty($pdata['password'])&&empty($pdata['wallet_address'])){
                      $this->result([], 0, '请输入内容!');
                  }
 
                  if (!empty($pdata['password'])&&strlen($pdata['password']) < 6) {
                      $this->result([], 0, '密码长度不能低于6位');
                  }

                  $data=[];

                  if(!empty($pdata['oldpassword'])&&($pdata['oldpassword']!=$pdata['password'])){
                     $data['loginpwd']=md5($pdata['password']);
                  }

                  if(!empty($pdata['wallet_address'])){

                        if(strlen($pdata['wallet_address'])<20){
                          $this->result([], 0, '钱包地址格式不正确!');
                        }                     
                       $data['wallet_address']=$pdata['wallet_address'];
                  }

                  $data['userid']=$this->getUid();

                  $result = BindUsersModel::editSave($data);
           
                    return  $this->result($result);
           } else{



                  $uid = $this->getUid();
                  $field='loginpwd,loginpwd,loginname,firstname,phone,email,wallet_address';
                  $user=Db::name('bind_users')->field($field)->where(['userid'=>$uid])->find();
                  $this->result($user, 1, '');

            }

    }



}
