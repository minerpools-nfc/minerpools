<?php
namespace app\api\controller;


use app\api\validate\ID;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use think\App;
use think\facade\Db;
use think\facade\Request;
use app\api\service\JwtAuth;
use think\Response;
use app\common\model\DrawApply as DrawApplyModel;

class Draw extends ABase
{

    protected $middleware = [
        'app\api\middleware\Api' => [],
    ];


    public function __construct(App $app)
    {
        parent::__construct($app);
    
    }



     public function index()
    {
        

        $pageNum=  Request::param('pageNum',1);
        $pageSize= Request::param('pageSize', config('app.page_size'));
    
        $owerid=Request::param('userid');
        $username=Request::param('username');

         $trans_status=Request::param('trans_status');
         $wallet_address=Request::param('wallet_address');
         $start_time=Request::param('start_time');
         $end_time=Request::param('end_time');

        // if(empty($owerid)){
        //        $this->result([], 0, '参数错误!');
        // }

        $where=[];
      

        if(!empty($username)){

          $uids=Db::name('bind_users')->where('firstname', 'like', '%'.$username.'%')->column('userid');
          $where[]=['userid','in',$uids];   
        }



         if($this->isapp()){
             $where[] = ['userid', '=', $this->getUid()];
        }else{
              if(!empty($owerid)){
                $where[]=['userid','=',$owerid];   
              }
        }



        if(!empty($trans_status)){
          $where[]=['trans_status','=',$trans_status];   
        }


        if(!empty($start_time)){
          $where[]=['addtime','>=',$start_time.' 00:00:00'];   
        }

         if(!empty($end_time)){
          $where[]=['addtime','<=',$end_time.' 23:59:59'];   
        }


        $order=['addtime'=>'desc'];
        $field='applyid,userid,wallet_address,draw_num,share_num,trans_status,remark,addtime';
  
        if($pageNum>0){
               $lists=Db::name('draw_apply')->where($where)->field($field)->order($order)->page($pageNum,$pageSize)->select()->toArray(); 
        }else{
               $lists=Db::name('draw_apply')->where($where)->field($field)->order($order)->select()->toArray();  
        }


        $total= Db::name('draw_apply')->where($where)->count();


         foreach ($lists as $k => &$v) {

          //   if($v["trans_status"] == 1)  $v["trans_status_label"] = "未提币";
             if($v["trans_status"] == 1)  $v["trans_status_label"] = "提币申请中";
             if($v["trans_status"] == 2)  $v["trans_status_label"] = "提币完成";
             if($v["trans_status"] == 3)  $v["trans_status_label"] = "后台转账中";
         //    if($v["trans_status"] == 4)  $v["trans_status_label"] = "提币失败";

                $v["draw_num"] = (float)$v["draw_num"];
                $v["share_num"] = (float)$v["share_num"];

              $username= Db::name('bind_users')->where('userid', $v['userid'])->find(); 
              $v["firstname"] =$username["firstname"];
              $v["lastname"] =$username["lastname"];

         } 




        $data=[
            'table'=>[
                 "page"=>$pageNum,
                 "pageSize"=>$pageSize,
                 "rows" =>$lists,
                 "total"=>$total,
             ]
        ];
      
        return $this->result($data, 1, '');
    }



    public function indexstatic(){ //提取头部统计

               

                 $apply_allnum=Db::name('draw_apply')->count();
                 $apply_num_complete=Db::name('draw_apply')->where('trans_status',2)->count();
               

                  $draw_all_nfc=Db::name('draw_apply')->sum('share_num');
                  $draw_complete_nfc=Db::name('draw_apply')->where('trans_status',2)->sum('share_num');
                  $draw_wait_nfc=Db::name('release_record')->where('draw_status',1)->sum('sharenum');
                  $draw_process_nfc=Db::name('draw_apply')->where('trans_status',1)->sum('share_num');

                 $data=[
                    'apply_allnum'=> $apply_allnum,
                    'apply_num_complete'=> $apply_num_complete,
                    'draw_all_nfc'=>floatval($draw_all_nfc),
                    'draw_complete_nfc'=>floatval($draw_complete_nfc),
                    'draw_wait_nfc'=>floatval($draw_wait_nfc),
                    'draw_process_nfc'=>floatval($draw_process_nfc)
                 ];


                 $this->result($data,1,'');



   }


    public function info(){



                     $id=input('applyid'); 
                     if(empty($id)){
                         $this->result([], 0, '参数错误!');
                     }

                      $field='applyid,userid,wallet_address,draw_num,share_num,trans_status,remark,addtime,updatetime';

                      $data=Db::name('draw_apply')->field($field)->where('applyid',$id)->find();
                      $user=Db::name('bind_users')->field('firstname,lastname')->where('userid',$data['userid'])->find();
                      $data['firstname']=$user['firstname'].$user['lastname'];


                      if(!$data){
                          $this->result([], 0, '记录不存在!');
                      }

                      return  $this->result($data);


    }






     public function deal(){



                    $pdata = Request::except(['file'], 'post');
                     if(empty($pdata['applyid'])||empty($pdata['type'])){
                         $this->result([], 0, '参数错误!');
                     }


                   if($pdata['type']==2&&empty($pdata['prikey'])) {
                        $this->result([], 0, '请输入密钥!');
                   }    

                     $apply=Db::name('draw_apply')->where(['applyid'=>$pdata['applyid']])->find();

                      if(!$apply){
                        $this->result([], 0, '申请单错误不存在!');
                    }


                    if($apply['trans_status']!=1){
                        $this->result([], 0, '该申请单已经处理过了!');
                    }


                 


                     $updata=[];
                     $updata['applyid']=$pdata['applyid'];
                     if(!empty($pdata['remark'])){
                          $updata['remark']=$pdata['remark'];
                     }

                     

             if ($pdata['type']==1) {     //手动转账      

                        Db::startTrans();
                         try {
                                $updata['type']=1;
                                $updata['trans_status']=2;
                                $updata['updatetime']=date('Y-m-d H:i:s');
                                $updata['updateby']=$this->getUid();


                              DrawApplyModel::editSave($updata);

                              $rdata=[
                                    "draw_status"=>3,
                                    "updatetime" => date('Y-m-d H:i:s'),
                                    "transtime" =>  date('Y-m-d H:i:s')
                              ];

                              Db::name('release_record')->where('applyid',$pdata['applyid'])->update($rdata);

                               list($msec, $sec) = explode(' ', microtime());
                               $msectime = (float)sprintf('%.0f', (floatval($msec) + floatval($sec)) * 1000);

                               $url="http://127.0.0.1:8446/v1/nfc/apply?random=".$msectime;
                             // $url="http://192.168.100.96:8446/v1/nfc/apply?random=".$msectime;  
                              $result=curl_request($url);    
                              if($result!='ok'){
                                    throw new \Exception("Error Processing Request", 1);
                              }   
                               Db::commit();


                          } catch (\Exception $e) {

                              Db::rollback();
                              $this->result([], 0, '操作失败');
                          }

                         $this->result([], 1, '操作成功!');

              }


              if ($pdata['type']==2) {  
                          $updata['type']=2;
                          DrawApplyModel::editSave($updata);
                        //    $ppdata=[

                        //  "applyid"=>$pdata['applyid'],

                        //   "prikey"=>""

                        // ];
                     
                       
                           list($msec, $sec) = explode(' ', microtime());
                           $msectime = (float)sprintf('%.0f', (floatval($msec) + floatval($sec)) * 1000);

                           $url="http://127.0.0.1:8446/v1/nfc/transferapply?random=".$msectime;
                         //  $url="http://192.168.100.96:8446/v1/nfc/transferapply?random=".$msectime;

                           $postdata='{"applyid":"'.$pdata['applyid'].'","prikey":"'.$pdata['prikey'].'"}';    
  
                            $result=curl_request($url,$postdata,$method='POST_JSON');
             
                            $result=json_decode($result,true);


                          //  print_r($result);die();

                            if(array_key_exists('result', $result)){
                                  if($result['result']==0){
                                      $this->result([], 1, $result['errmsg']);
                                  }else{
                                      $this->result([], 0, $result['errmsg']);
                                  }
                                     
                            }else{
                                     $this->result([], 0, '操作错误,稍后重试');
                            } 

              }
                    

    }



       public function release()
    {
        

        $pageNum=  Request::param('pageNum',1);
        $pageSize= Request::param('pageSize', config('app.page_size'));
    
        $applyid=Request::param('applyid');      

        $flowid=Request::param('flowid');      

        $draw_status=Request::param('draw_status');    

        $where=[];
        if(!empty($applyid)){
          $where[]=['applyid','=',$applyid];   
        }

         if(!empty($flowid)){
          $where[]=['flowid','=',$flowid];   
        }

        if(!empty($draw_status)){
          $where[]=['draw_status','=',$draw_status];   
        }

        $order=['updatetime'=>'desc'];
        $field='releaseid,ctime,userid,devicesn,nfc_num,share_rate,sharenum,takenum,applyid,draw_status,transtime';
  
        if($pageNum>0){
               $lists=Db::name('release_record')->where($where)->field($field)->order($order)->page($pageNum,$pageSize)->select()->toArray(); 
        }else{
               $lists=Db::name('release_record')->where($where)->field($field)->order($order)->select()->toArray();  
        }


        $total= Db::name('release_record')->where($where)->count();
         foreach ($lists as $k => &$v) {

                $v["nfc_num"] = (float)$v["nfc_num"];
                $v["sharenum"] = (float)$v["sharenum"];
                $v["takenum"] = (float)$v["takenum"];
                $v["username"] =Db::name('bind_users')->where('userid', $v["userid"])->value('firstname');

         } 

        $data=[
            'table'=>[
                 "page"=>$pageNum,
                 "pageSize"=>$pageSize,
                 "rows" =>$lists,
                 "total"=>$total,
             ]
        ];
      
        return $this->result($data, 1, '');
    }





        public function waitdraw()  //app wait draw
    {
        

        $pageNum=  Request::param('pageNum',1);
        $pageSize= Request::param('pageSize', config('app.page_size'));
    
        $devicesn=Request::param('devicesn');    

       

        $where=[];
  
        $uid= $this->getUid();
        $devices=Db::name('devices')->where('owerid',$uid)->column('devicesn');
        $where[]=['devicesn','in',$devices];  


        if(!empty($devicesn)){
          $where[]=['devicesn','=',$devicesn];   
        }


        $where[]=['draw_status','<>',2];   




        $order=['updatetime'=>'desc'];
        $field='flowid,ctime,devicesn,sharenum,drawnum,sharenum-drawnum  waitdraw';
  
        $lists=Db::name('device_tocken_record')->where($where)->field($field)->order($order)->page($pageNum,$pageSize)->select()->toArray(); 
        $total= Db::name('device_tocken_record')->where($where)->count();

         foreach ($lists as $k => &$v) {
                $v["sharenum"] = floatval(sprintf('%.2f',$v["sharenum"]));
                $v["drawnum"] = floatval(sprintf('%.2f',$v["drawnum"]));
                $v["waitdraw"] = floatval(sprintf('%.2f',$v["waitdraw"]));
         } 

        $data=[
            'table'=>[
                 "page"=>$pageNum,
                 "pageSize"=>$pageSize,
                 "rows" =>$lists,
                 "total"=>$total,
             ]
        ];
      
        return $this->result($data, 1, '');
    }








     public function locklist()  //app 锁仓
    {
        

        $pageNum=  Request::param('pageNum',1);
        $pageSize= Request::param('pageSize', config('app.page_size'));
    
        $uid= $this->getUid();
        $devicesn=Request::param('devicesn');


        $devices=Db::name('devices')->where('owerid',$uid)->column('devicesn');


        $where=[];
        $where[]=['devicesn','in',$devices];  



        if(!empty($devicesn)){
          $where[]=['devicesn','=',$devicesn];   
        }


        $order=['addtime'=>'desc'];
        $field='devicesn,sum(sharenum)  as sharesum,sum(hasrelease*share_rate/100) as hasrelease,sum(sharenum)-sum(hasrelease*share_rate/100) as locknfc';
  

         $lists=Db::name('device_tocken_record')->where($where)->field($field)->group('devicesn')->page($pageNum,$pageSize)->select()->toArray(); 


         $total= Db::name('device_tocken_record')->where($where)->field($field)->group('devicesn')->count();


         foreach ($lists as $k => &$v) {

               $v["sharesum"] =sprintf("%.4f",floatval($v["sharesum"]));
               $v["hasrelease"] =sprintf("%.4f",floatval($v["hasrelease"]));
               $v["locknfc"] =sprintf("%.4f",floatval($v["locknfc"]));
         } 




        $data=[
            'table'=>[
                 "page"=>$pageNum,
                 "pageSize"=>$pageSize,
                 "rows" =>$lists,
                 "total"=>$total,
             ]
        ];
      
        return $this->result($data, 1, '');
    }






    public function  appstatic(){

          $uid=$this->getUid();
          $mydevices=Db::name('devices')->where('owerid',$uid)->column('devicesn');      

          $myallnfc=Db::name('device_tocken_record')->where('devicesn','in',$mydevices)->sum('sharenum');

          $my_unlocknfc=Db::name('release_record')->where(['userid'=>$uid])->sum('sharenum'); //已释放

          $my_locknfc=floatval(sprintf("%.2f",$myallnfc-$my_unlocknfc)); //锁仓

        //  $my_hasdraw=Db::name('release_record')->where(['userid'=>$uid,'draw_status'=>3])->sum('sharenum'); //已提取
           $my_hasdraw=Db::name('draw_apply')->where(['userid'=>$uid,'trans_status'=>2])->sum('share_num');//已提取

          $my_waitdraw=Db::name('release_record')->where([['userid','=',$uid],['draw_status','in','1,4']])->sum('sharenum'); //待提取

           $my_indraw=Db::name('draw_apply')->where(['userid'=>$uid,'trans_status'=>1])->sum('share_num'); //提取中
         
          $data=[         
            "my_unlocknfc"=>floatval(sprintf("%.2f",$my_unlocknfc)),
            "my_locknfc"=>floatval(sprintf("%.2f",$my_locknfc)),    
            "my_waitdraw"=>floatval(sprintf("%.2f",$my_waitdraw)),
            "my_hasdraw"=>floatval(sprintf("%.2f",$my_hasdraw)),
            "my_indraw"=>floatval(sprintf("%.2f",$my_indraw)),
          ];

           $this->result($data, 1, '');

    }



     public function  dodraw(){ //app提币申请

             Db::startTrans();

             // $wallet_address=Request::param('wallet_address');
             // if(empty($wallet_address)){
             //     $this->result([], 0, '请输入提币钱包地址!');
             // }


            $uid=$this->getUid();                     

            $where=[
               ['userid','=',$uid],
               ['draw_status','=',1]
            ];
            $share_num=Db::name('release_record')->where($where)->sum('sharenum');
            $draw_num=Db::name('release_record')->where($where)->sum('takenum');


            $min_drawnum=Db::name('sys_config')->where('prop_flag','min_drawnum')->value('prop_value');

            if($share_num<$min_drawnum){
                 $this->result([], 0, '可提数量小于'.$min_drawnum.',暂不能提取!');
            }


             $wallet_address=Db::name('bind_users')->where('userid',$uid)->value('wallet_address');
             if(!$wallet_address){
                    $this->result([], 5, '你未设置钱包地址,请先去设置!');
             }  

           try {        

            $drawno='NO'.getOrderNo();

            $dataapply=[
                'applyid'=>$drawno,
                'userid' => $uid,
                'wallet_address'=>$wallet_address,
                'draw_num'=>$draw_num,
                'share_num'=>$share_num,
                'trans_status'=>1,
                'addtime'=>date('Y-m-d H:i:s'),
                'addby'=> $uid,
                'updatetime'=>date('Y-m-d H:i:s'),
                'updateby'=> $uid
            ];         

            Db::name('draw_apply')->insert($dataapply);    
            Db::name('release_record')->where($where)->update(['draw_status'=>2,'applyid'=>$drawno]);  

            Db::commit();

        } catch (\Exception $e) {

            Db::rollback();

            $this->result([], 0, '操作失败');
        }

        $this->result([], 1, '申请成功');

    }



    /*
    * 导出
    */
    public function export(){
        $params = $this->request->param();

        $where = array();
        if (array_key_exists('trans_status', $params)&&!empty($params['trans_status'])){
            $where[] = ['trans_status', '=', $params['trans_status']];
        }
        if (array_key_exists('wallet_address', $params)&&!empty($params['wallet_address'])){
            $where[] = ['wallet_address', '=', $params['wallet_address']];
        }

         $start_time=Request::param('start_time');
         $end_time=Request::param('end_time');



        if(!empty($params['username'])){

           $uids=Db::name('bind_users')->where('firstname', 'like', '%'.$username.'%')->column('userid');
           $where[]=['userid','in',$uids];   
        }


      
        if(!empty($params['start_time'])){
          $where[]=['addtime','>=',$start_time.' 00:00:00'];   
        }

         if(!empty($params['end_time'])){
          $where[]=['addtime','<=',$end_time.' 23:59:59'];   
        }


        $applys = DrawApplyModel::getExportList($where);


        $transStatus = ['未提币', '提币申请中', '提币完成', '提币失败'];

        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();

        $sheet->setCellValue('A1', '申请时间');
        $sheet->setCellValue('B1', '用户');
        $sheet->setCellValue('C1', '提币数量');
        $sheet->setCellValue('D1', '提成数量');
        $sheet->setCellValue('E1', '状态');
        $sheet->setCellValue('F1', '钱包地址');
        $sheet->setCellValue('G1', '备注');
  

        foreach ($applys as $key => $apply) {
            $sheet->setCellValue('A'.($key+2), $apply['addtime']);
            $sheet->setCellValue('B'.($key+2), $apply->user->firstname);
            $sheet->setCellValue('C'.($key+2), $apply['share_num']);
            $sheet->setCellValue('D'.($key+2), $apply['draw_num']);
            $sheet->setCellValue('E'.($key+2), $transStatus[$apply['trans_status']]);
            $sheet->setCellValue('F'.($key+2), $apply['wallet_address']);
            $sheet->setCellValue('G'.($key+2), $apply['remark']);
        }

        $writer = new Xlsx($spreadsheet);
        $filename='申请导出-'.date('YmdHis'). '.xlsx';
        $writer->save(public_path().'uploads/excel/'.$filename);

        $path=Request::domain().'/uploads/excel/'.$filename;

        $this->result($path, 1, '导出成功!');
    }



}
