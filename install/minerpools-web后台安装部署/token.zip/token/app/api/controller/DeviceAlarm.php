<?php
namespace app\api\controller;


use app\api\validate\ID;
use think\App;
use think\facade\Db;
use think\facade\Request;
use app\api\service\JwtAuth;
use think\Response;
use app\common\model\DeviceAlarm as DevicesAlarmModel;

class DeviceAlarm extends ABase
{

    protected $middleware = [
        'app\api\middleware\Api' => [],
    ];


    public function __construct(App $app)
    {
        parent::__construct($app);
    
    }


     public function index()
    {
        

        $pageNum=  Request::param('pageNum',1);
        $pageSize= Request::param('pageSize', config('app.page_size'));



        $devicesn=Request::param('devicesn');
        $username=Request::param('username');
        $servity=Request::param('servity');
    
        $where=[];
      

        if(!empty($username)){

          $uids=Db::name('bind_users')->where('firstname', 'like', '%'.$username.'%')->column('userid');
          $where[]=['userid','in',$uids];   
        }


         if(!empty($devicesn)){
          $where[]=['devicesn','=',$devicesn];   
        }


         if(!empty($servity)){
          $where[]=['servity','=',$servity];   
        }
        

        $order=['instime'=>'desc'];
        $lists=DevicesAlarmModel::pageList($pageNum,$pageSize,$field='alarmid,devicesn,userid,alarm_type,firsttime,lasttime,servity,alarm_title,alarm_msg,instime',$where,$order);      

        $data=[
            'table'=>[
                 "page"=>$pageNum,
                 "pageSize"=>$pageSize,
                 "rows" =>$lists['tablelist'],
                 "total"=>$lists['total'],
             ]
        ];



        return $this->result($data, 1, '');
    }

  
    


}
