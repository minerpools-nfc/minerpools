<?php
namespace app\api\controller;


use app\api\validate\ID;
use think\App;
use think\facade\Db;
use think\facade\Request;
use app\api\service\JwtAuth;
use think\Response;
use app\common\model\AuthGroup as AuthGroupModel;

class AuthGroup extends ABase
{

    protected $middleware = [
        'app\api\middleware\Api' => [],
    ];


    public function __construct(App $app)
    {
        parent::__construct($app);
    
    }



  

     public function index()
    {
     
        $pageNum=  Request::param('pageNum',1);
        $pageSize= Request::param('pageSize', config('app.page_size'));


        $title=Request::param('title');

        $where=[];
        if(!empty($title)){
          $where[]=['title','like','%'.$title.'%'];   
        }


        $field='id,title,status,create_time,update_time';
        $lists=AuthGroupModel::pageList($pageNum,$pageSize,$field,$where);


        $data=[
            'table'=>[
                 "page"=>$pageNum,
                 "pageSize"=>$pageSize,
                 "rows" =>$lists['tablelist'],
                 "total"=>$lists['total'],
             ]
        ];
      
        return $this->result($data, 1, '');




    }

  



   
    public function add(){

         $title=input('title');
         $status=input('status');
         $rules=input('rules');

         if(empty($title)){
             $this->result([], 0, '参数错误!');
        }

 
        $id =AuthGroupModel::where('title', '=',$title)->find();
        if ($id) {
            $this->result([], 0, '该名称已存在');
        }

      
        $data = [];
        $data['title']         = $title;
        $data['status']        = $status;
        $data['rules']        = $rules;
        $data['create_time']     = time();
    
        $id =AuthGroupModel::insertGetId($data);
        if ($id) {
            $this->result([], 1, '添加成功');
        } else {
            $this->result([], 0, '添加失败');
        }
    }





    public function edit(){

         if (Request::isPost()) { 
           
              $data = Request::except(['file'], 'post');

      
              if(empty($data['id'])){
                 $this->result([], 0, '参数错误!');
              }

             $result =AuthGroupModel::editSave($data);
     
             return  $this->result($result);
        }else{

                $id=Request::param('id');

               //  $authsarr=Db::name('auth_rule')->where(['status'=>1,'auth_set'=>1])->field('id,pid,title')->order(['id'=>'desc','sort'=>'asc'])->select()->toArray();

               // $rules = Db::name('auth_group')->where('id', $id)->value('rules');
               // $rules_arr = explode(',',$rules);


               //  foreach ($authsarr as &$auth){
                   
               //         if(in_array($auth['id'],$rules_arr)){
               //              $auth['checked']=true;
               //          }else{
               //              $auth['checked']=false;
               //          }
               //  }

               //  $auths=childList($authsarr);

                $data=AuthGroupModel::getOne(['id'=>$id],'id,title,status,rules');    

              //  $data['auths']= $auths;

                 return  $this->result($data);

        }

    }



     public function delete()
     {

        $id=input('id'); 
        if(empty($id)){
             $this->result([], 0, '参数错误!');
        }

        if (Request::isPost()) {           
            if($id==1) return $this->result([],0,'超级管理员组不能删除');
             $result=AuthGroupModel::del($id);
            return $this->result($result);
        }
    }



     public function rules()
     {
          
            $id=input('id'); 
            if(empty($id)){
                 $this->result([], 0, '参数错误!');
            }

           $authsarr=Db::name('auth_rule')->where(['status'=>1,'auth_set'=>1])->field('id,pid,title')->order(['id'=>'desc','sort'=>'asc'])->select()->toArray();

           $rules = Db::name('auth_group')->where('id', $id)->value('rules');
           $rules_arr = explode(',',$rules);


            foreach ($authsarr as &$auth){
               
                   if(in_array($auth['id'],$rules_arr)){
                        $auth['checked']=true;
                    }else{
                        $auth['checked']=false;
                    }
            }

           $auths=childList($authsarr);
           return $this->result($auths);
      
     }

      public function  setrules()
     {
          
            $id=input('id'); 
            $rules=input('rules');
            if(empty($id)||empty($rules)){
                 $this->result([], 0, '参数错误!');
            }

            $result= Db::name('auth_group')->where('id', $id)->update(['rules'=>$rules]);

            if($result){
                 return  $this->result([], 1, '设置成功!');
            }else{
                 return  $this->result([], 0,  '操作失败,请重试!');
            }
     
     }




}







