<?php
namespace app\api\controller;


use app\api\validate\ID;
use think\App;
use think\facade\Db;
use think\facade\Request;
use app\api\service\JwtAuth;
use think\Response;
use app\common\model\DevicesType as DevicesTypeModel;
use app\common\model\DeviceNfcRecord as DeviceNfcRecordModel;


class DevicesType extends ABase
{

    protected $middleware = [
        'app\api\middleware\Api' => [],
    ];


    public function __construct(App $app)
    {
        parent::__construct($app);
    
    }


     public function index()
    {
        $pageNum=  Request::param('pageNum',1);
        $pageSize= Request::param('pageSize', config('app.page_size'));
        $data=DevicesTypeModel::pageList($pageNum,$pageSize,$field='id,name');
      
        return $this->result($data, 1, '');

      
    }

  
    
   
    public function add(){

         $name=input('name');
        if(empty($name)){
             $this->result([], 0, '名称不能为空!');
        }

        $id =DevicesTypeModel::where('name', '=', $name)->find();
        if ($id) {
            $this->result([], 0, '该名称已存在');
        }
        $data=['name'=>$name];
   
        $id = DevicesTypeModel::insertGetId($data);
        if ($id) {
            $this->result([], 1, '添加成功');
        } else {
            $this->result([], 0, '添加失败');
        }
    }





    public function edit(){
       
          if (Request::isPost()) {          
                 $data = Request::except(['file'], 'post');
                 if(empty($data['id'])||empty($data['name'])){
                     $this->result([], 0, '名称或编号不能为空!');
                }
                  
                $result = DevicesTypeModel::editSave($data);
           
                    return  $this->result($result);
           } else{

                $id=Request::param('id');
                $data=DevicesTypeModel::getOne(['id'=>$id]);         

                 return  $this->result($data);


            }

    }



     public function editmore(){
       
          if (Request::isPost()) {          
                $data = Request::except(['file'], 'post');
                if(empty($data)){
                             return  $this->result([],0,'修改的内容不能为空');
                } 

               foreach ($data as $key => $item) {


                    if(empty($item['id'])||empty($item['name'])){
                        $this->result([], 0, '名称或编号不能为空!');
                    }
                   
                     $result =DevicesTypeModel::editSave($item);
                     if(!$result){                                
                          return  $this->result([],0,'修改失败');
                      }  
                }

                return  $this->result($result);
           } else{

                $id=Request::param('id');
                $data=DevicesTypeModel::getOne(['id'=>$id]);         

                 return  $this->result($data);


            }

    }



     public function delete()
     {

        $id=input('id'); 
        if(empty($id)){
             $this->result([], 0, '参数错误!');
        }

        if (Request::isPost()) { 
             $result=DevicesTypeModel::del($id);
             return $this->result($result);
        }
    }



}
