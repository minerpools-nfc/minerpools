<?php
declare (strict_types = 1);

namespace app\api\controller;

use think\App;
use think\facade\Config;
use think\facade\Db;
use think\facade\Request;
use think\Response;
use think\Validate;
use think\exception\HttpResponseException;
use app\api\service\JwtAuth;

/**
 * 控制器基类
 */
abstract class ABase
{
    /**
     * Request实例
     * @var \think\Request
     */
    protected $request;

    /**
     * 应用实例
     * @var \think\App
     */
    protected $app;

    protected $middleware = [];

    protected $pageSize = '';

    /**
     * 构造方法
     * @access public
     * @param  App $app 应用对象
     */
      public function __construct(App $app)
    {
        $this->app = $app;
        $this->request = $this->app->request;

       // 控制器初始化
        $this->initialize();
    }

    // 初始化
    protected function initialize()
    {
        //每页显示数据量
        //$this->pageSize = Request::param('page_size', Config::get('app.page_size'));
    }


    protected function getUid(){
        $jwtAuth = JwtAuth::getInstance();
        return $jwtAuth->getUid();
    }



    protected function isapp(){
            $device = Request::header('device');
           if($device=='app'){
                 return true;
           }else{
                return false;
           }
    }



   


    protected function result($data = [], int $code = 1, $msg = 'ok',$type = '', $header = [])
    {
        $result = [
            'code' => $code,
            'msg'  => $msg,
            'data' => $data,
        ];

        $type     = $type ?: 'json';
        $response = Response::create($result, $type)->header($header);

        throw new HttpResponseException($response);
    }

}
