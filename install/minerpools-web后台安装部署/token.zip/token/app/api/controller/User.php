<?php
namespace app\api\controller;


use app\api\validate\ID;
use think\App;
use think\facade\Db;
use think\facade\Request;
use app\api\service\JwtAuth;
use think\Response;
use app\common\model\AdminUser as Users;
use app\common\model\AuthGroup as AuthGroupModel;

class User extends ABase
{

    protected $middleware = [
        'app\api\middleware\Api' => ['except' => ['login']],
    ];


    public function __construct(App $app)
    {
        parent::__construct($app);
    
    }



    public function login()
    {
      
         $username=input('username');
         $password=input('password');
         if(empty($username)||empty($password)){
             $this->result([], 0, '用户名和密码不能为空!');
        }
        $user = Users::where('username', $username)
            ->where('password',md5(md5($password)))
            ->find();
        if (empty($user)) {
            $this->result([], 0, '帐号或密码错误');
        } else {
            if ($user['status'] == 1) {
   
                $jwtAuth = JwtAuth::getInstance();
                $token = $jwtAuth->setUid($user['id'])->encode()->getToken();

                Users::where('id', $user['id'])
                    ->update(['login_time' => time(), 'login_ip' => Request::ip()]);


                $auth=AuthGroupModel::where('id',$user['auth_group_id'])->find();

                $data=[
                    'userid'=>$user['id'],
                    'username'=>$user['username'],
                    'auth_group_name'=>$auth['title'],
                    'auth_rules'=>$auth['rules'],
                    'token' => $token
                ];


                $this->result($data, 1, '登录成功');
            } else {
                $this->result([], 0, '用户已被禁用');
            }
        }
    }



     public function index()
    {

        $pageNum=  Request::param('pageNum',1);
        $pageSize= Request::param('pageSize', config('app.page_size'));

        $auth_group_id=Request::param('auth_group_id');
        $username=Request::param('username');

        $where=[];
        if(!empty($auth_group_id)){
          $where[]=['auth_group_id','=',$auth_group_id];   
        }
        if(!empty($username)){
          $where[]=['username','like','%'.$username.'%'];   
        }


        $field='id,username,status,auth_group_id,create_time,update_time';
        $lists=Users::pageList($pageNum,$pageSize,$field,$where);


        $data=[
            'table'=>[
                 "page"=>$pageNum,
                 "pageSize"=>$pageSize,
                 "rows" =>$lists['tablelist'],
                 "total"=>$lists['total'],
             ]
        ];
      
        return $this->result($data, 1, '');
    }

  



   
    public function add(){

         $username=input('username');
         $password=input('password');
         $typeid=input('auth_group_id');
         $status=input('status') ;
         if(empty($username)||empty($password)||empty($typeid)){
             $this->result([], 0, '参数错误!');
        }

        if (strlen($password) < 6) {
            $this->result([], 0, '密码长度不能低于6位');
        }

        $id =Users::where('username', '=', $username)->find();
        if ($id) {
            $this->result([], 0, '该用户名已存在');
        }

      
        $data = [];
        $data['username']        = $username;
        $data['password']        = md5(md5($password));
        $data['auth_group_id']   = $typeid ;
        $data['status']          = $status;
        $data['create_time']     = time();
    
        $id = Users::insertGetId($data);
        if ($id) {
            $this->result([], 1, '添加成功');
        } else {
            $this->result([], 0, '添加失败');
        }
    }





    public function edit(){
       
          if (Request::isPost()) {          
                  $data = Request::except(['file'], 'post');
                 if(empty($data['id'])||empty($data['password'])||empty($data['oldpassword'])){
                     $this->result([], 0, '参数错误!');
                }
                  
                  if (strlen($data['password']) < 6) {
                    $this->result([], 0, '密码长度不能低于6位');
                   }

                    if($data['oldpassword']!=$data['password']){
                        $data['password']=md5(md5($data['password']));
                    }

                    $result = Users::editSave($data);
           
                    return  $this->result($result);
           } else{

                $id=Request::param('id');
                $data=Users::getOne(['id'=>$id],'id,auth_group_id,username,password,status');         

                 return  $this->result($data);


            }

    }



    public function myinfo(){
       
          if (Request::isPost()) {          
                  $pdata = Request::except(['file'], 'post');
                 if(empty($pdata['password'])&&empty($pdata['oldpassword'])){
                     $this->result([], 0, '参数错误!');
                }
                  


                  if (strlen($pdata['password']) < 6) {
                      $this->result([], 0, '密码长度不能低于6位');
                  }

                  $data=[];

                  if($pdata['oldpassword']!=$pdata['password']){
                     $data['password']=md5(md5($pdata['password']));
                  }

                  if(!empty($pdata['username'])){
                       $data['username']=$pdata['username'];
                  }

                  $data['id']=$this->getUid();

                  $result = Users::editSave($data);
           
                    return  $this->result($result);
           } else{

                $id=$this->getUid();
                $data=Users::getOne(['id'=>$id],'auth_group_id,username,password');  
                $auth_rules=AuthGroupModel::where('id',$data['auth_group_id'])->value('rules');    
                $data['auth_rules']=$auth_rules;

                 return  $this->result($data);


            }

    }




     public function delete()
     {

        $id=input('id'); 
        if(empty($id)){
             $this->result([], 0, '参数错误!');
        }

        if (Request::isPost()) {           
            if($id==1) return $this->result([],0,'管理员账号不能删除');
             $result=Users::del($id);
            return $this->result($result);
        }
    }



     public function usertype()
     {
            $result=Db::name('auth_group')->field('id,title')->select();
            return $this->result($result);
      
     }


}
