<?php
namespace app\api\controller;
use think\facade\Db;
use think\facade\Cache;
use think\facade\Request;
use app\common\model\Message;

class Common extends ABase
{
	protected $middleware = [
	   'app\api\middleware\Api' => ['except' => ['contentDetail','getBannerList','getBaseData']],
	];
		
	
    /**
     * add by djg 2020.8.4
     * 根据分组类型获取banner图片
     * @param string $type
     * @throws \think\db\exception\DataNotFoundException
     * @throws \think\db\exception\DbException
     * @throws \think\db\exception\ModelNotFoundException
     */
	public function getBannerList($type=1){

          $data=Db::name('ad')->where('type','=',$type)->field(['image','url','name'])->select()->toArray();

          if(count($data)>0){

                $imgPrefix=sysconfig('imgPrefix');

                $data_res=[];
                foreach($data as $k=>$item){
                     if (!strpos($item['image'], 'http') !== false) {                   
                           $data[$k]['image']=$imgPrefix.$item['image'];
                      }
               }
           }
          return result($data);
    }

     public function getBaseData(){

            $contactphone=sysconfig('contactphone');
            $data=[
                'contactphone'=>$contactphone
            ];
            $this->result($data,1,'');
     }


      public  function  message()
    {
     
          $title=Request::param("title");
          //$name=Request::param("name");
        //$phone=Request::param("phone");
          $content=Request::param("content");

          if(empty($title)||empty($content))    $this->result([], 0, '标题和内容不能为空');  


          $uid=$this->getUid();

          $c=Db::name('message')->where(['uid'=>$uid,'status'=>0])->count();
          if($c>2){
             $this->result([],0, '你已经有未处理留言超过3条,不能再提交了');
          }


          $message           = new Message;
          $message ->uid  = $uid;
          $message ->title   = $title;
          //  $message ->name    =  $name;
          //  $message ->phone   = $phone;
          $message ->content = $content;
          $result=$message->save();
          if($result){
            $this->result([],1, '添加留言成功');
          }else{
            $this->result([],0, '添加失败，稍后重试');
          }
          
    
    }


      public  function  contentDetail()
     {

            $id=Request::param("id");
            $mid=Request::param("mid");
      
            if(!$id&&!$mid)     $this->result([], 1, '缺少必要参数');          

            if($mid==1){
              $page = Db::name('page')->field('title,content')->where(['id'=>$id,'status'=>1])->find();   
              $this->result($page, 1, '');

            }else if($mid==2){
              $page = Db::name('article')->field('title,content')->where(['id'=>$id,'status'=>1])->find();      
              $this->result($page, 1, '');

            }else{
               $this->result([], 1, '');
            }
    }


     public  function  contentList()
    { 

      $cid=Request::param("cid");
      $pageStart=Request::param("pageStart")?Request::param("pageStart"):1;
      $pageSize=Request::param("pageSize")?Request::param("pageSize"):20;
      
      if(!$cid) {
        $this->result([], 1, '缺少必要参数');
      }     

      $pagelist = Db::name('article')->where('cate_id',$cid)->fieldRaw('id,title,FROM_UNIXTIME(update_time,"%Y/%m/%d") time')->page($pageStart,$pageSize)->select()->toArray();      
      $this->result($pagelist, 1, '');
    }


	
}
