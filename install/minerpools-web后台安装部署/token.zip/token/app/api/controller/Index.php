<?php

namespace app\api\controller;


use app\common\model\DeviceTockenRecord as TokenRecordModel;
use think\App;
use think\facade\Db;
use think\facade\Request;
use think\Response;
use app\common\model\Devices as DeviceModel;
use app\common\model\BindUsers as BindUserModel;
use app\common\model\DeviceAlarm as DeviceAlarmModel;
use app\common\model\DrawApply as DrawApplyModel;
use app\common\model\ReleaseRecord as ReleaseRecordModel;


class Index extends ABase
{


    protected $middleware = [
        'app\api\middleware\Api' => ['except' => ['', '']],
    ];

    public function appstatic()
    { //app首页

                $uid = $this->getUid();
                $mydevices=Db::name('devices')->where('owerid',$uid)->column('devicesn');

                $myallnfc=Db::name('device_tocken_record')->where('devicesn','in',$mydevices)->sum('sharenum');

             //   $mynfc_yesterday=Db::name('device_tocken_record')->where('devicesn','in',$mydevices)->whereDay('ctime', 'yesterday')->sum('sharenum');
            //    $mynfc_today=Db::name('device_tocken_record')->where('devicesn','in',$mydevices)->whereDay('ctime')->sum('sharenum');

                $mydevice_num=Db::name('devices')->where('owerid',$uid)->where('delete_flag',1)->count();

                $mydevices_online =Db::name('devices')->where('delete_flag',1)->where(['owerid'=>$uid,'online_status'=>1])->count();
                $mydevices_offline=Db::name('devices')->where('delete_flag',1)->where(['owerid'=>$uid,'online_status'=>0])->count();


             //   $my_mbpoint=Db::name('bind_users')->where('userid',$uid)->value('mbpoint'); //积分

                $my_unlocknfc=Db::name('release_record')->where(['userid'=>$uid])->sum('sharenum'); //已释放
            //     $my_unlocknfc=Db::name('device_tocken_record')->where('devicesn','in',$mydevices)->sum('hasrelease'); //已释放


                $my_locknfc=floatval(sprintf("%.2f",$myallnfc-$my_unlocknfc)); //锁仓

                $my_hasdraw=Db::name('release_record')->where(['userid'=>$uid,'draw_status'=>3])->sum('sharenum'); //已提取

                $my_waitdraw=Db::name('release_record')->where(['userid'=>$uid,'draw_status'=>1])->sum('sharenum'); //待提取

                $my_indraw=Db::name('release_record')->where(['userid'=>$uid,'draw_status'=>2])->sum('sharenum'); //提取中

                $data=[
                    "myallnfc"=>floatval(sprintf("%.2f",$myallnfc)),
                 //   "mynfc_yesterday"=>floatval(sprintf("%.2f",$mynfc_yesterday)),
                 //   "mynfc_today"=>floatval(sprintf("%.2f",$mynfc_today)),
                    "mydevice_num"=>$mydevice_num,
                    "mydevices_online"=>$mydevices_online,
                    "mydevices_offline"=>$mydevices_offline,
                //    "my_mbpoint"=>mbpoint_format($my_mbpoint),
                    "my_locknfc"=>floatval(sprintf("%.2f",$my_locknfc)),
                    "my_unlocknfc"=>floatval(sprintf("%.2f",$my_unlocknfc)),
                    "my_hasdraw"=>floatval(sprintf("%.2f",$my_hasdraw)),
                    "my_waitdraw"=>floatval(sprintf("%.2f",$my_waitdraw)),
                    "my_indraw"=>floatval(sprintf("%.2f",$my_indraw)),
                ];

                 $this->result($data, 1, '');

    }


    /*
     * 首页 - 统计部分
     */
    public function static()
    {
        $statistics = array();
        $charts = array();
        //1. 矿机总数，矿机状态饼形图 zs_devices
        $devData = DeviceModel::static();
        $statistics['device_num'] = $devData['total'];//矿机总数
        $facilityPie = [
            ['num' => $devData['online'], 'name' => 'online', 'label' => '在线矿机'],
            ['num' => $devData['offline'], 'name' => 'offline', 'label' => '离线矿机'],
        ];
        $charts['facilityPie'] = $facilityPie;

        //2. 积分不足用户   zs_bind_users
        $statistics['low_mbpoint_num'] = BindUserModel::countPointAlarm();

        //3. 预警数量   zs_device_alarm
        $statistics['alarm_num'] = DeviceAlarmModel::count();

        //4. 提交申请待办数 zs_draw_apply
        $statistics['apply_do'] = DrawApplyModel::countApplyNum();

        //5. 提成收益 zs_release_record takenum 统计
        $releaseData = ReleaseRecordModel::static();
        $statistics['user_has_take'] = floatval(sprintf("%.2f",$releaseData['user_has_take']));
        $statistics['release_untake'] = floatval(sprintf("%.2f",$releaseData['un_take']));

        //9. 锁仓总量 zs_device_token_record (nfc_num - hasrelease) 的统计
        $deviceNfcData = TokenRecordModel::staticLockRecord();
        $statistics['take_total'] = floatval(sprintf("%.2f",$deviceNfcData['take_total']));
        $statistics['user_share_total'] = floatval(sprintf("%.2f",$deviceNfcData['share_total']));
        $statistics['lock_total'] = floatval(sprintf("%.2f",$deviceNfcData['lock_total']));
        $statistics['hasrelease_all'] = floatval(sprintf("%.2f",$deviceNfcData['hasrelease_all']));

        
      
        $earningsPie = [
            ['num' => $deviceNfcData['take_total'], 'name' => 'take_total', 'label' => '提成收益'],
            ['num' => $deviceNfcData['share_total'], 'name' => 'share_total', 'label' => '用户收益']
        ];
        $charts['earningsPie'] = $earningsPie;

        $userLock = $deviceNfcData['share_total'] - $releaseData['user_has_take'] - $releaseData['user_un_take'];
        $userPie = [
            ['num' => $releaseData['user_has_take'], 'name' => 'has_take', 'label' => '已提取'],
            ['num' => $releaseData['user_un_take'], 'name' => 'un_take', 'label' => '未提取'],
            ['num' =>  number_format($userLock, 8), 'name' => 'lock', 'label' => '锁仓' ]
        ];
        $charts['userPie'] = $userPie;

        $takeLock = $deviceNfcData['take_total'] - $releaseData['release'];
        $percentagePie = [
            ['num' => $releaseData['release'], 'name' => 'release', 'label' => '释放'],
            ['num' => $takeLock, 'name' => 'lock', 'label' => '锁仓']
        ];
        $charts['percentagePie'] = $percentagePie;

        $data = ['statistics' => $statistics, 'charts' => $charts];
        return $this->result($data);
    }


    /*
     * 收益曲线图
     */
    public function curve(){
        $start = $this->request->param('start');
        $end = $this->request->param('end');
        if (!$start && !$end){//开始时间，结束时间都没有。默认表示最近 7 天
            $where = 'DATE_SUB(CURDATE(),INTERVAL 7 DAY) <= instime';
        }else{
            $where = "STR_TO_DATE(instime, '%Y-%m-%d')	BETWEEN STR_TO_DATE('{$start}','%Y-%m-%d') AND STR_TO_DATE('{$end}','%Y-%m-%d')";
        }

        $data = TokenRecordModel::incomeCurve($where);
        return $this->result(['earnings' => $data]);
    }


}
