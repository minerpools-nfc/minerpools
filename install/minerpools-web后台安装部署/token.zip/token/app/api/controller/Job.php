<?php
/**
 *
 * @创建时间 2021/3/24 9:34
 */

namespace app\api\controller;

use app\common\model\JobLog as JobLogModel;
use app\common\model\Job as JobModel;
use app\common\validate\JobList;
use think\Exception;


class Job extends ABase
{
    protected $middleware = [
        'app\api\middleware\Api' => [],
    ];

    /*
     * 列表
     */
    public function index()
    {
        (new JobList())->goCheck();
        $param = $this->request->param();
        $pageNum = $this->request->param('pageNum', 1);
        $pageSize = $this->request->param('pageSize', config('app.page_size'));

        $where = [];
        if (array_key_exists('job_enable', $param)&&strlen($param['job_enable'])>0)
        {
            $where[] = ['job_enable', '=', $param['job_enable']];
        }
        if (array_key_exists('execresult', $param)&&strlen($param['execresult'])>0)
        {
            $where[] = ['execresult', '=', $param['execresult']];
        }
        if (array_key_exists('job_name', $param)&&!empty($param['job_name'])){
            $where[] = ['job_name', 'like', '%'. $param['job_name'] .'%'];
        }


        $data = [
            'table' => [
                "page" => $pageNum,
                "pageSize" => $pageSize,
                "total" => JobModel::where($where)->count(),
                "rows" => JobModel::pageList($pageNum, $pageSize, $where),
            ]
        ];
        return $this->result($data);
    }


    /*
     * 详情/修改
     */
    public function edit()
    {
        $params = $this->request->param();

        if (!array_key_exists('jobid', $params)){
            return $this->result([], 0, 'jobid不能为空');
        }

        $job = JobModel::where('jobid', $params['jobid'])->find();

        if (!$job)
        {
            return $this->result([], 0, '定时任务不存在');
        }

        if ($this->request->isPost() && count($params) > 1)//post请求，多个参数表示修改
        {
            try
            {   
                if(empty($params['starttime']))  unset($params['starttime']);
                if(empty($params['endtime']))  unset($params['endtime']);
                unset($params['exectime']);

                $params['updatetime'] = date('Y-m-d H:i:s');
                $params['updateby'] = $this->getUid();
                $job->save($params);
            }
            catch (Exception $e)
            {
                return $this->result([], 0, '更新失败');
            }
            return $this->result([], 1, '修改成功');
        }
        return $this->result($job);
    }

    /*
     * 新增
     */
    public function add(){
        $params = $this->request->param();

        $params['updatetime'] = date('Y-m-d H:i:s');
        $params['updateby'] = $this->getUid();

        $jobModel = new JobModel();
        $jobModel->save($params);

        return $this->result([]);
    }

    /*
     * 删除
     */
    public function del(){
        $jobId = $this->request->param('jobid');

        $job = JobModel::where('jobid', $jobId)->find();
        if (!$job)
        {
            return $this->result([], 0, '定时任务不存在');
        }
        $job->delete();
        return $this->result([]);
    }

    /*
     * 详情对应日志
     */
    public function log(){
        $jobid = $this->request->param('jobid');
        $pageNum = $this->request->param('pageNum', 1);
        $pageSize = $this->request->param('pageSize', config('app.page_size'));

        $job = JobModel::where('jobid', $jobid)->find();

        if (!$job)
        {
            return $this->result([], 0, '定时任务不存在');
        }

        $where[] = ['jobid', '=', $jobid];

        $data = [
            'table' => [
                "page" => $pageNum,
                "pageSize" => $pageSize,
                "total" => JobLogModel::where($where)->count(),
                "rows" => JobLogModel::pageList($pageNum, $pageSize, $where),
            ]
        ];
        return $this->result($data);
    }


}