<?php
namespace app\api\controller;


use app\api\validate\ID;
use app\common\model\SysConfig as SysConfigModel;
use app\common\validate\SettingModify;
use think\App;
use think\Exception;
use think\facade\Db;
use think\facade\Request;

class Setting extends ABase
{

    protected $middleware = [
        'app\api\middleware\Api' => [],
    ];


    public function __construct(App $app)
    {
        parent::__construct($app);
    
    }


    

  
    public function email(){
      

       if (Request::isPost()) {       

                $data = Request::except(['file'], 'post');    

                if(empty($data)){
                     return  $this->result([],0,'修改的内容不能为空');
                } 

                  $indata=[]; 
                  if(empty($data['authpwd'])||empty($data['authname'])||empty($data['emailaddr'])||empty($data['hostname'])){
                      return  $this->result([],0,'请填写完整要提交的内容！');                    
                  }            
                        $indata['authpwd']=$data['authpwd'];
                        $indata['emailaddr']=$data['emailaddr'];
                        $indata['email_name']=$data['email_name'];
                        $indata['hostname']=$data['hostname'];
                        $indata['authname']=$data['authname'];
                        $indata['eamilport']=$data['eamilport'];
                        $indata['ssl_enable']=$data['ssl_enable'];
                        $indata['updatetime']=date('Y-m-d H:i:s');
                        $indata['updateby']=$this->getUid();
                     
                $result = Db::name('email_setting')->where('emailid',1)->update($indata);

                if($result){
                      return  $this->result([],1,'修改成功');
                }else{
                      return  $this->result([],0,'修改失败');
                }   
                
        }else{

                $data=Db::name('email_setting')->where('emailid',1)->field('emailaddr,email_name,hostname,authname,authpwd,ssl_enable,eamilport')->find();
                return  $this->result($data);

        }

    }


     public function  interface(){

                if (Request::isPost()) {       

                        $data = Request::except(['file'], 'post');    

                        if(empty($data)){
                             return  $this->result([],0,'修改的内容不能为空');
                        } 

                        if(intval($data['intaval'])<4){
                             return  $this->result([],0,'间隔时间不能小于4分钟');
                        }


                        $indata=[]; 
                        if($data['userpwd']!=$data['olduserpwd']){
                            $indata['userpwd']=md5($data['userpwd']);
                        }     

                        $indata['username']=$data['username'];
                        $indata['intaval']=$data['intaval'];                    
                        $indata['updatetime']=date('Y-m-d H:i:s');
                        $indata['updateby']=$this->getUid();
                             
                        $result = Db::name('dpool_interface')->where('interid',1)->update($indata);

                        if($result){
                              return  $this->result([],1,'修改成功');
                        }else{
                              return  $this->result([],0,'修改失败');
                        }   
                        
                }else{

                        $data=Db::name('dpool_interface')->where('interid',1)->field('httpurl,nfcurl,username,userpwd,intaval')->find();
                        return  $this->result($data);

                }

    }




    public function  alarm(){

                if (Request::isPost()) {       

                $data = Request::except(['file'], 'post');    

                if(empty($data)){
                     return  $this->result([],0,'修改的内容不能为空');
                } 

                if($data['mbpoint']<0){
                     return  $this->result([],0,'积分不能小于0');
                }

                $indata=[]; 
              
                $indata['mbpoint']=$data['mbpoint'];
                $indata['onlinestatus']=$data['onlinestatus'];
                $indata['interfacestatus']=$data['interfacestatus'];
                $indata['email']=$data['email'];
                $indata['updatetime']=date('Y-m-d H:i:s');
                $indata['updateby']=$this->getUid();
                     
                $result = Db::name('device_alarm_config')->where('cfgid',1)->update($indata);

                if($result){
                      return  $this->result([],1,'修改成功');
                }else{
                      return  $this->result([],0,'修改失败');
                }   
                
        }else{

                $data=Db::name('device_alarm_config')->where('cfgid',1)->field('mbpoint,onlinestatus,interfacestatus,email')->find();
                return  $this->result($data);

        }
    }

/*
    [
      {    
          "cfgid":1,
          "cfg_name",
          "cfg_msg":,
          "cfg_type",1
          "threshold":20,
          "servity":2,
          "enable":0
      },
       {    
          "cfgid":1,
          "cfg_name",
          "cfg_msg":,
          "cfg_type",1
          "threshold":20,
          "servity":2,
          "enable":0
      },
       {    
          "cfgid":1,
          "cfg_name",
          "cfg_msg":,
          "cfg_type",1
          "threshold":20,
          "servity":2,
          "enable":0
      },
  
   ]

*/

    // public function alarm(){

    //             if (Request::isPost()) {       

    //                     $datas = Request::except(['file'], 'post');    

    //                     if(empty($datas)){
    //                          return  $this->result([],0,'修改的内容不能为空');
    //                     } 


    //                     foreach ($datas as $key => $data) {
    //                          $data['updatetime']=date('Y-m-d H:i:s');
    //                          $data['updateby']=$this->getUid();
    //                          $result = Db::name('device_alarm_config')->where('cfgid',$data['cfgid'])->update($data);
    //                          if(!$result){                                
    //                               return  $this->result([],0,'修改失败');
    //                           }  
    //                     }

    //                     return  $this->result([],1,'修改成功');
 
                        
    //             }else{

    //                     $data=Db::name('device_alarm_config')->field('cfgid,cfg_msg,cfg_name,threshold,servity,enable,email')->select();
    //                     return  $this->result($data);

    //             }

    // }



    // public function alarmpoint(){

    //             if (Request::isPost()) {       

    //                     $data = Request::except(['file'], 'post');    

    //                     if(empty($data)){
    //                          return  $this->result([],0,'修改的内容不能为空');
    //                     } 

    //                     $data['updatetime']=date('Y-m-d H:i:s');
    //                     $data['updateby']=$this->getUid();

                             
    //                     $result = Db::name('device_alarm_config')->where('cfgid',1)->update($data);

    //                     if($result){
    //                           return  $this->result([],1,'修改成功');
    //                     }else{
    //                           return  $this->result([],0,'修改失败');
    //                     }   
                        
    //             }else{

    //                     $data=Db::name('device_alarm_config')->where('cfgid',1)->field('httpurl,username,userpwd,intaval')->find();
    //                     return  $this->result($data);

    //             }

    // }


    //  public function alarmonline(){

    //             if (Request::isPost()) {       

    //                     $data = Request::except(['file'], 'post');    

    //                     if(empty($data)){
    //                          return  $this->result([],0,'修改的内容不能为空');
    //                     } 

    //                     $data['updatetime']=date('Y-m-d H:i:s');
    //                     $data['updateby']=$this->getUid();

                             
    //                     $result = Db::name('device_alarm_config')->where('cfgid',3)->update($data);

    //                     if($result){
    //                           return  $this->result([],1,'修改成功');
    //                     }else{
    //                           return  $this->result([],0,'修改失败');
    //                     }   
                        
    //             }else{

    //                     $data=Db::name('device_alarm_config')->where('cfgid',3)->field('httpurl,username,userpwd,intaval')->find();
    //                     return  $this->result($data);

    //             }

    // }



    //  public function alarminterface(){

    //             if (Request::isPost()) {       

    //                     $data = Request::except(['file'], 'post');    

    //                     if(empty($data)){
    //                          return  $this->result([],0,'修改的内容不能为空');
    //                     } 

    //                     $data['updatetime']=date('Y-m-d H:i:s');
    //                     $data['updateby']=$this->getUid();

                             
    //                     $result = Db::name('device_alarm_config')->where('cfgid',3)->update($data);

    //                     if($result){
    //                           return  $this->result([],1,'修改成功');
    //                     }else{
    //                           return  $this->result([],0,'修改失败');
    //                     }   
                        
    //             }else{

    //                     $data=Db::name('device_alarm_config')->where('cfgid',3)->field('httpurl,username,userpwd,intaval')->find();
    //                     return  $this->result($data);

    //             }
    // }


    /*
     * 获取全局配置
     */
    public function getConfig(){
        $configs = SysConfigModel::field('cfgid,prop_name,prop_remark,prop_flag,prop_type,prop_units,prop_value')->select();
        return $this->result($configs);
    }

    /*
     * 修改全局配置
     */
    public function update(){
        (new SettingModify())->goCheck();

        $data = $this->request->param('setting');

        Db::startTrans();
        try
        {
            foreach ($data as $item){
                $config = SysConfigModel::where('cfgid',  $item['cfgid'])->find();
                $config->prop_value = $item['prop_value'];
                $config->updatetime = date('Y-m-d H:i:s');
                $config->updateby = $this->getUid();
                $config->save();
            }
            Db::commit();
        }catch (Exception $e){
            Db::rollback();
            return $this->result([], 0, '更新失败');
        }
        return $this->result();
    }




    


}
