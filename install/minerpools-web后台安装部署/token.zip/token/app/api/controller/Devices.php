<?php

namespace app\api\controller;


use app\api\validate\ID;
use app\common\model\Devices as DevicesModel;
use app\common\model\DeviceTockenRecord as DeviceTockenRecordModel;
use app\common\validate\DeviceBatchModify;
use app\common\validate\TokenRecord;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use think\App;
use think\facade\Db;
use think\facade\Request;
use app\common\model\BindUsers as BindUserModel;

class Devices extends ABase
{

    protected $middleware = [
        'app\api\middleware\Api' => [],
    ];


    public function __construct(App $app)
    {
        parent::__construct($app);

    }


    public function index()
    {
        $pageNum = Request::param('pageNum', 1);
        $pageSize = Request::param('pageSize', config('app.page_size'));
     //   $lowmbpoit = Request::param('lowmbpoit');
        $online_status = Request::param('online_status');
        $device_status = Request::param('devicestatus');
        $typeid = Request::param('typeid');

        $devicesn = Request::param('devicesn');

        $owerid = Request::param('owerid');

        $deleteflag=Request::param('delete_flag');

        $share_rate=Request::param('share_rate');
        $lockdays=Request::param('lockdays');
        $releasedays=Request::param('releasedays');

        $where = [];
        $haswhere = [];

        if (strlen($online_status))
        {
            $where[] = ['online_status', '=', $online_status];
        }

         if(strlen($device_status)){
             $where[] = ['devicestatus', '=', $device_status];
           
         }


        if (!empty($typeid))
        {
            $where[] = ['typeid', '=', $typeid];
        }
          if (!empty($share_rate))
        {
            $where[] = ['share_rate', '=', $share_rate];
        }
          if (!empty($lockdays))
        {
            $where[] = ['lockdays', '=', $lockdays];
        }
          if (!empty($releasedays))
        {
            $where[] = ['releasedays', '=', $releasedays];
        }

        if ($this->isapp())
        {
            $where[] = ['owerid', '=', $this->getUid()];
        }
        else
        {
            if (!empty($owerid))
            {
                $where[] = ['owerid', '=', $owerid];
            }
        }

        if (!empty($devicesn))
        {
            $where[] = ['devicesn', 'like', '%'.$devicesn.'%'];
        }


        if(!empty($deleteflag)){
 
                  $where[] = ['delete_flag', '=', 2];
                       
         }else{

                 $where[] = ['delete_flag', '=',1];    
         }



        //        $lowmbpoit_num = Db::name('device_alarm_config')
        //            ->where('cfgid', 1)
        //            ->value('mbpoint');

        // if (!empty($lowmbpoit))
        // {

        //     if ($lowmbpoit == 1)
        //     {
        //         $where[] = ['w.mbpoint_alarm', '=', 1];
        //     }

        //     if ($lowmbpoit == 2)
        //     {

        //         $where[] = ['w.mbpoint_alarm', '=', 0];
        //     }
        // }


        $order = ['createtime' => 'desc'];
        $field =
            'devicesn,devicestatus,online_status,delete_flag,device_class,calval,calmodel,online_time,offline_time,ower_name,referername,device_ip,device_vip,device_localtion,share_rate,lockdays,releasedays';
        //    $lists=DevicesModel::pageList($pageNum,$pageSize,$field,$where,$order,$haswhere);
        $lists = Db::name('devices')
         //   ->alias('a')
        //    ->join('bind_users w', 'a.owerid=w.userid')
            ->where($where)
            ->field($field)
            ->order($order)
            ->page($pageNum, $pageSize)
            ->select()
            ->toArray();
         foreach ($lists as $k => &$v)
         {
            // $typename = Db::name('devices_type')
            //     ->where('id', $v['typeid'])
            //     ->value('name');
            // if ($typename)
            // {
            //     $lists[$k]['typename'] = $typename;
            // }
            // else
            // {
            //     $lists[$k]['typename'] = '';
            // }

            //  $todaybill= Db::name('devices_type')->where('id', $v['typeid'])->value('name');


            $lists[$k]['share_rate'] = floatval($lists[$k]['share_rate']);

        }


        $total = Db::name('devices')
         //   ->alias('a')
           // ->join('bind_users w', 'a.owerid= w.userid')
            ->where($where)
            ->count();

        $data = [
            'table' => [
                "page" => $pageNum,
                "pageSize" => $pageSize,
                "rows" => $lists,
                "total" => $total,
            ]
        ];

        return $this->result($data, 1, '');
    }


    public function edit()
    {


        if (Request::isPost())
        {

            $data = Request::except(['file'], 'post');
            if (empty($data['devicesn']))
            {
                $this->result([], 0, '矿机编号不能为空!');
            }

            if ($data['share_rate']<0)
            {
                $this->result([], 0, '分成比例不能小于0!');
            }

            $indata = [
                'devicesn' => $data['devicesn'],
                'referercode' => $data['referercode'],
                'referername' => $data['referername'],
             //   'typeid' => $data['typeid'],
                'share_rate' => $data['share_rate'],
                'lockdays' => $data['lockdays'],
                'releasedays' => $data['releasedays'],
                'area_name' => !empty($data['area_name'])?$data['area_name']:'',
                'phy_location' =>!empty($data['phy_location'])? $data['phy_location']:'',
                'device_room' =>!empty($data['device_room'])? $data['device_room']:'',
                'frame_location' =>!empty($data['frame_location'])? $data['frame_location']:'',
                'cabinet_num' =>!empty($data['cabinet_num'])? $data['cabinet_num']:''
            ];
            $indata['updatetime'] = date('Y-m-d H:i:s');
            $indata['updateby'] = $this->getUid();

            $result = DevicesModel::editSave($indata);

            return $this->result($result);
        }
        else
        {


            $sn = Request::param('devicesn');
            $data = DevicesModel::getOne(['devicesn' => $sn]);

            return $this->result($data);

        }

    }


    public function type()
    {
        $result = Db::name('devices_type')
            ->field('id,name')
            ->select();
        return $this->result($result);

    }

    /*
     * 收益记录 - tocken_record 数据
     */
    public function record()
    {

        (new TokenRecord())->goCheck();

        $params = $this->request->param();
        $pageNum = $this->request->param('pageNum', 1);
        $pageSize = $this->request->param('pageSize', config('app.page_size'));

        $where = array();
        if (array_key_exists('devicesn', $params)&&!empty($params['devicesn']))
        {
            $where[] = ['devicesn', '=', $params['devicesn']];
        }

        if (array_key_exists('firstname', $params)&&!empty($params['firstname']))
        {
            $uid = BindUserModel::where('firstname', $params['firstname'])->value('userid');
            $ids = DevicesModel::where('owerid', $uid)->column('devicesn');
            $where[] = ['devicesn', 'in', $ids];
        }


        if ($this->isapp())
        {
            $ids = DevicesModel::where('owerid',$this->getUid())->column('devicesn');
            $where[] = ['devicesn', 'in', $ids];
        }




        //按时间段查询
        if (array_key_exists('start_time', $params) && $params['start_time']){
            $start = date('Y-m-d', strtotime($params['start_time']));

            if (array_key_exists('end_time', $params) && $params['end_time']){//按时间段查询
                $end = date('Y-m-d', strtotime($params['end_time']));
                $where[] = ['ctime', '>=', $start];
                $where[] = ['ctime', '<=', $end];
            }else{//查询具体时间
                $where[] = ['ctime', '=', $start];
            }
        }

        $order = ['ctime' => 'desc'];
        $field = 'flowid,ctime,devicesn,flow_bill,nfc_num,sharenum,takenum,hasrelease,hasrelease*share_rate/100 user_release,sharenum-hasrelease*share_rate/100 user_locknum,drawnum';

        $data = [
            'table' => [
                "page" => $pageNum,
                "pageSize" => $pageSize,
                "total" => DeviceTockenRecordModel::where($where)->count(),
                "rows" => DeviceTockenRecordModel::pageList($pageNum, $pageSize, $field, $where, $order)
            ]
        ];
        return $this->result($data);
    }

    /*
     * 收益详情 tocken_record 单条数据
     */
    public function singleRecord(){
        $flowId = $this->request->param('flowid');
        if (!$flowId){
            return result([], 0, 'flowid 不能为空');
        }
        $record = DeviceTockenRecordModel::where('flowid', $flowId)->find();
        if (!$record){
            return result([], 0, '该记录不存在');
        }
        $record->user = $record->device ? $record->device->BindUsers->firstname : '';


        $record['flow_bill']=flowbill_format($record['flow_bill']);

      //  $record->releases;
        $record->hidden(['device']);

        return result($record);
    }


    public function apprecordall() //矿机流量统计
    {
        $devicesn = input('devicesn');
        if (empty($devicesn))
        {
            $this->result([], 0, '参数错误!');
        }

        $data = DevicesModel::getOne(
            ['devicesn' => $devicesn], 'online_status,device_localtion');

        $flow_bill_all = DeviceTockenRecordModel::where('devicesn', $devicesn)
            ->sum('flow_bill');
        $hasrelease_all = DeviceTockenRecordModel::where('devicesn', $devicesn)
            ->sum('sharenum');
        $hasrelease_all = DeviceTockenRecordModel::where('devicesn', $devicesn)
            ->sum('hasrelease');


        $data['flow_bill_all'] = $flow_bill_all;
        $data['sharenum_all'] = $hasrelease_all;
        $data['hasrelease_all'] = $hasrelease_all;

        return $this->result($data, 1, '');
    }

    /*
     * 导出
     */
    public function export()
    {
        $params = $this->request->param();

        $where = array();
        if (array_key_exists('online_status', $params)&&!empty($params['online_status'])){
            $where[] = ['online_status', '=', $params['online_status']];
        }  

       if (array_key_exists('typeid', $params)&&!empty($params['typeid']))
        {
            $where[] = ['typeid', '=', $params['typeid']];
        }
       //  $lowmbpoit = Request::param('lowmbpoit');

        if(!empty($params['delete_flag'])){ 
            $where[]= ['delete_flag', '=',2];                     
        }


        $devices = DevicesModel::getExportList($where);

        $deviceStatus = ['未激活', '正常', '锁定', '作废'];
        $deleteStatus = ['', '正常', '删除'];

        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();

        $sheet->setCellValue('A1', '矿机sn');
        $sheet->setCellValue('B1', 'iP');
        $sheet->setCellValue('C1', '虚拟iP');
        $sheet->setCellValue('D1', '矿机状态');
        $sheet->setCellValue('E1', '登录时间');
        $sheet->setCellValue('F1', '离线时间');
        $sheet->setCellValue('G1', '位置');
        $sheet->setCellValue('H1', '矿机分组');
        $sheet->setCellValue('I1', '删除状态');


        foreach ($devices as $key => $detail) {
            $sheet->setCellValue('A'.($key+2), $detail['devicesn']);
            $sheet->setCellValue('B'.($key+2), $detail['device_ip']);
            $sheet->setCellValue('C'.($key+2), $detail['device_vip']);
            $sheet->setCellValue('D'.($key+2), $deviceStatus[$detail['devicestatus']]);
            $sheet->setCellValue('E'.($key+2), $detail['online_time']);
            $sheet->setCellValue('F'.($key+2), $detail['offline_time']);
            $sheet->setCellValue('G'.($key+2), $detail['device_localtion']);
            $sheet->setCellValue('H'.($key+2), $detail->DevicesType?$detail->DevicesType->name:'');
            $sheet->setCellValue('I'.($key+2), $deleteStatus[$detail['delete_flag']]);

        }

        $writer = new Xlsx($spreadsheet);
        $filename = '矿机导出-' . date('YmdHis') . '.xlsx';
        $writer->save(public_path() . 'uploads/excel/' . $filename);

        $path = Request::domain() . '/uploads/excel/' . $filename;

        $this->result($path, 1, '导出成功!');
    }
    


    public function recordapp() //矿机流量收益记录
    {

        $devicesn = input('devicesn');
        $start_date = Request::param('start_date');
        $end_date = Request::param('end_date');


        if (empty($devicesn))
        {
            $this->result([], 0, '参数错误!');
        }

        $where = [];

        $where[] = ['devicesn', '=', $devicesn];

        if (!empty($start_date) && !empty($end_date))
        {
            if (strtotime($start_date) > strtotime($end_date))
            {
                $this->result([], 0, '开始日期不能早于结束时间!');
            }

        }

        if (empty($start_date) && empty($end_date))
        {

            $start_date = date('Y-m-d', strtotime('-1 months'));
            $where[] = ['ctime', '>=', $start_date];
        }


        if (!empty($start_date))
        {
            $where[] = ['ctime', '>=', $start_date];
        }


        if (!empty($end_date))
        {
            $where[] = ['ctime', '<=', $end_date];
        }


        $date_list = [];
        $flowbill_list = [];
        $sharenum_list = [];
        $release_list = [];

        $field ='flowid,ctime,flow_bill,devicesn,nfc_num,share_rate,sharenum,takenum,hasrelease';
        $lists = Db::name('device_tocken_record')
            ->field($field)
            ->where($where)
            ->order('ctime', 'asc')
            ->select();
        foreach ($lists as $key => $record)
        {

            $date_list[] = $record['ctime'];
            $flowbill_list[] = floatval(sprintf('%.4f', $record['flow_bill']));
            $sharenum_list[] = floatval(sprintf('%.4f', $record['sharenum']));
            $release_list[] = floatval(sprintf('%.4f', $record['hasrelease']));
        }


        $data = [

            'date_list' => $date_list,
            'flowbill_list' => $flowbill_list,
            'sharenum_list' => $sharenum_list,
            'release_list' => $release_list
        ];


        $this->result($data, 1, '');

    }

    public function batchModify(){
        (new DeviceBatchModify())->goCheck();

        $params = $this->request->param();
        $idArr = explode(',', $params['ids']);
        $count = DevicesModel::where('devicesn', 'in', $idArr)->count();
        if ($count != count($idArr)){
            return $this->result([], 0, '参数异常');
        }

        $temp = array();
        if (array_key_exists('share_rate', $params)){
            $temp['share_rate'] = $params['share_rate'];
        }
        if (array_key_exists('lockdays', $params)){
            $temp['lockdays'] = $params['lockdays'];
        }
        if (array_key_exists('releasedays', $params)){
            $temp['releasedays'] = $params['releasedays'];
        }
        if (array_key_exists('referercode', $params) && $params['referercode']){
            $temp['referercode'] = $params['referercode'];
        }
        if (array_key_exists('referername', $params) && $params['referername']){
            $temp['referername'] = $params['referername'];
        }


        if (array_key_exists('area_name', $params) && $params['area_name']){
            $temp['area_name'] = $params['area_name'];
        }
        if (array_key_exists('phy_location', $params) && $params['phy_location']){
            $temp['phy_location'] = $params['phy_location'];
        }
        if (array_key_exists('device_room', $params) && $params['device_room']){
            $temp['device_room'] = $params['device_room'];
        }
        if (array_key_exists('frame_location', $params) && $params['frame_location']){
            $temp['frame_location'] = $params['frame_location'];
        }
        if (array_key_exists('cabinet_num', $params) && $params['cabinet_num']){
            $temp['cabinet_num'] = $params['cabinet_num'];
        }


        $data = array();
        foreach ($idArr as $id){
            $tmp['devicesn'] = $id;
            $data[] = array_merge($tmp, $temp);
        }

        $deviceModel = new DevicesModel();
        $deviceModel->saveAll($data);

        return $this->result();
    }


}
