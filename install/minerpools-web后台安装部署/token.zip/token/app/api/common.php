<?php
function flowbill_format($v) {

	 $number=sprintf("%.2f",floatval($v/1073741824)); //GB

     return $number;
}

