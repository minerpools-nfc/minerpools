<?php
namespace app\api\middleware;

use app\api\service\JwtAuth;

use think\facade\Request;
use think\facade\Db;
use think\Response;
use think\exception\HttpResponseException;

class Api
{
    public function handle($request, \Closure $next)
    {
        $token = Request::header('token');

        if ($token) {
            if (count(explode('.', $token)) <> 3) {
                $this->result([], 9, 'token格式错误');
            }
            $jwtAuth = JwtAuth::getInstance();
            $jwtAuth->setToken($token);
            if ($jwtAuth->validate() && $jwtAuth->verify()) {


                      // $device = Request::header('device');
                      // if($device!='app'){//pc管理端     
                      //           //检测权限
                      //            $userid = $jwtAuth->getUid();     
                      //            $whitelist = [          
                      //               'User/login',      // 登录     
                      //            ];
                      //           $route = Request::controller() . '/' . lcfirst(Request::action());
                      //           if ($userid != 1) {  //1 超级管理员
                      //               if (!in_array($route, $whitelist)) { 
                      //                       $result = $this->checkRules($route, $userid);
                      //                       if (!$result) {
                      //                           $this->result([],0,'错误,没有此操作权限!');
                      //                       }
                      //                   }
                      //           }

                      //  }

                return $next($request);
            } else {
                $this->result([], 9, 'token已经过期');
            }
        } else {
            $this->result([], 9, 'token不能为空');
        }

    }




   public function  checkRules($route,$userid){   
     
                 $user=Db::name('admin_user')->where('id','=',$userid)->find();       
                 $rules = Db::name('auth_group')->field('id,rules,title')->where(['id'=>$user['auth_group_id'],'status'=>1])->find();   

                  $rulearr = explode(',',$rules['rules']);
                  $route_ruleid = Db::name('auth_rule')->where('name',$route)->value('id');   

               if(empty($rules))  return false;       
               if($route_ruleid&&!in_array($route_ruleid,$rulearr))  return false;    
               if($route_ruleid&&in_array($route_ruleid,$rulearr))  return true; 
    }

 



 
    protected function result($data, $code = 1, $msg = '', $type = '',$header = [])
    {
        $result = [
            'code' => $code,
            'msg'  => $msg,
            'data' => $data,
        ];

        $type     = $type ?: 'json';
        $response = Response::create($result, $type)->header($header);

        throw new HttpResponseException($response);
    }

}
