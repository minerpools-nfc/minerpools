<?php
$servername = "localhost";
$username = "dien_bc";
$password = "dien@ossbc123";
 
try {

    $conn = new PDO("mysql:host=localhost;port=12306;dbname=dpools;", $username, $password);
    echo "连接成功"; 
}
catch(PDOException $e)
{
    echo $e->getMessage();
}
?>