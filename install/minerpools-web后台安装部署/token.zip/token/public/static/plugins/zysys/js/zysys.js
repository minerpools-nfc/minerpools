

(function($){   

   $.extend({

   		gtable:{

   			_option: {}, 

   			init:function(obj){
   				$.gtable._option = obj;
   			},

   			add:function(){
   				window.location.href = $.gtable._option.add_url;
   			},

   			edit:function(value){
   				window.location.href = $.gtable._option.edit_url+'?'+$.gtable._option.primary_Key+'='+value;
   			},

   			delete:function(value){
   	      		 layer.confirm("确定要删除该条数据吗？", {icon: 3, title:'提示'}, function(index){
 						  $.gtable.ajaxpost($.gtable._option.delete_url, {ids: value});
						  layer.close(index);       
				    });
   			},

        deleteBatch:function(){
              var  hasSelect=false;
              var  ids="";
              $(".checkid").each(function(){
                   if(this.checked) {
                     ids+=this.value+',';
                     hasSelect=true;
                   } 
              });
              if(!hasSelect){
                 return layer.alert("请先勾选要删除的项目", {icon: 2});
              }
              ids=ids.substr(0,ids.length-1);
              //console.log(ids);
               layer.confirm("确定要删除选择的数据吗？", {icon: 3, title:'提示'}, function(index){
                  $.gtable.ajaxpost($.gtable._option.delete_url, {ids: ids});
                  layer.close(index);       
             });


        },


        switch:function(id,column,v){
         
              $.gtable.ajaxpost($.gtable._option.switch_url, {id:id,field:column,value:v});
                    
        },


        inputchange:function(id,column,obj){
         
              $.gtable.ajaxpost($.gtable._option.inputchange_url, {id:id,field:column,value:$(obj).val()});
                    
        },




   			ajaxpost: function(url,data,callback,type,dataType) {
                $.ajax({
                    url: url,
                    type: type?type:'post',
                    dataType: dataType?dataType:"json",
                    data: data,                 
                    success: function(result) {
                        if (callback) {
                            callback(result);
                        }
                        if (result.code == 1) {
			                    layer.alert(result.msg, {icon: 1});
			                    $.gtable._option.table_obj.ajax.reload();  // 刷新表格数据 重置分页信息
			                   // $.gtable.tableobj.ajax.reload( null, false ); // 刷新表格数据分页信息不会重置
      			            } else {
      			                   layer.alert(result.msg, {icon: 2});
      			            }
                   	}
                })
            },
   		},


      webuploader:function(url,name,more){

                      var uploader = WebUploader.create({     
                           auto: true,            
                            swf: '/static/plugins/webuploader/Uploader.swf',
                            server: url,
                            pick: '#filepicker_'+name,
                            resize: false
                        });


                        uploader.on( 'uploadProgress', function( file, percentage ) {
                            var $li = $( '#thelist_'+name),
                                $percent = $li.find('.progress .progress-bar');

                            // 避免重复创建
                            if ( !$percent.length ) {
                                $percent = $('<div class="progress progress-striped active">' +
                                  '<div class="progress-bar" role="progressbar" style="width: 0%">' +
                                  '</div>' +
                                '</div>').appendTo( $li ).find('.progress-bar');
                            }

                            $li.find('p.state').text('上传中');

                            $percent.css( 'width', percentage * 100 + '%' );
                        });


                        uploader.on( 'uploadSuccess', function(file,result) {
                            // $( '#'+file.id ).find('p.state').text('已上传');
                              if (result.code == 1) {
                                        var path = result.path;
                                        if (more == 1) { //多图上传
                                              var htm='<div class="row"><div class="col-sm-4 col-xs-4 mt-2"><label class="control-label"><img   src="'+path+'" title='+path+' width="60"  height="60" /></label></div><div class="col-xs-3 mt-4"><button type="button" class="btn btn-block btn-warning removeimages">删除</button></div></div>';
                                              $('#imagelist_'+name).append(htm);
                                              var ht='<input type="hidden" class="form-control" name="'+name+'[]" value="'+path+'" />';
                                              $('#imaghidden_'+name).append(ht);
                                              
                                        } else {
                                            $("input[name='" + name + "']").val(path); 
                                            $('#upimg_'+name).attr('src',path);                                         
                                        }                                                                       
                                }else{
                                      layer.alert(result.msg, {icon: 2});
                                }
                              

                        });

                        uploader.on( 'uploadError', function( file ) {
                             $( '#thelist_'+name).find('p.state').text('上传出错');
                        });

                        uploader.on( 'uploadComplete', function( file ) {
                             $( '#thelist_'+name).find('.progress').fadeOut();
                        });

      }


   });


  


})(jQuery);