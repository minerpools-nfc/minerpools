<?php

return [    
    // 验证码过期时间(S)
    'expire'   => 1800,
    // 中文验证码
    'useZh'    => false,
    // 算术验证码
    'math'     => false,
    // 背景图
    'useImgBg' => false,
    //验证码字符大小
    'fontSize' => 25,
    //验证码位数
    'length'   => 5,
    // 混淆曲线
    'useCurve' => true,
    //添加杂点
    'useNoise' => true,
    // 验证码字体 不设置则随机获取
    'fontttf'  => '',
    //背景颜色
    'bg'       => [234, 230, 253],
 
];
