
window.$url = {
    appUrl: 'http://localhost:8080/api/',
 

}
